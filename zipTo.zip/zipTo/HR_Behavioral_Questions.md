# Bajaj Finserv — CDAC Campus Hiring 2026
## HR & Behavioral Interview Questions
**Role:** Salesforce Hybrid (Dev + Admin) | **Round:** HR / Final  
**Scoring:** 1 (Poor) → 3 (Average) → 5 (Excellent)

---

## 1. FUNCTIONAL KNOWLEDGE & DOMAIN AWARENESS

| # | Question |
|---|---------|
| 1 | You're joining a financial services company. What do you understand by terms like EMI, loan tenure, interest rate, and processing fee? Give a simple example. |
| 2 | A customer asks you: "Why was my loan application rejected?" — What possible reasons can you think of from a system/business perspective? |
| 3 | If Bajaj Finserv offers Personal Loans, Home Loans, and Insurance — how do you think technology supports each of these products differently? |
| 4 | You hear the term "CRM" frequently in our company. What do you think a CRM system does, and why would a financial company need one? |
| 5 | What do you think happens behind the scenes when a customer applies for a loan on the Bajaj Finserv app? Walk me through the process as you imagine it. |
| 6 | How would you explain the difference between a bank and an NBFC (like Bajaj Finserv) to a non-technical person? |
| 7 | If a customer's loan EMI is ₹10,000/month for 24 months on a ₹2,00,000 loan — does the total repayment equal ₹2,00,000? Why or why not? |
| 8 | What do you understand about KYC (Know Your Customer)? Why is it important in financial services? |

---

## 2. TEAMWORK & COLLABORATION

| # | Question |
|---|---------|
| 1 | During your CDAC project, how did your team divide the work? What was your specific role, and how did you coordinate with others? |
| 2 | Tell me about a time when a teammate wasn't contributing their fair share. What did you do — did you cover for them, confront them, or escalate? |
| 3 | You and a teammate disagree on which technology to use for a module. You prefer Approach A, they prefer Approach B. How do you resolve this without creating conflict? |
| 4 | Imagine you finish your assigned task 2 days early, but your teammate is struggling with theirs and the deadline is tomorrow. What do you do? |
| 5 | Your team has 5 members and a 2-week deadline. One member falls sick for a week. How does the team handle this situation? |
| 6 | How do you handle a situation where the team lead makes a decision you disagree with? Do you speak up or just follow along? |
| 7 | Describe your ideal team environment. What kind of people do you work best with, and what kind of teammates frustrate you? |
| 8 | Have you ever had to work with someone whose working style was completely different from yours? How did you adapt? |

---

## 3. PEOPLE MANAGEMENT & INTERPERSONAL SKILLS

| # | Question |
|---|---------|
| 1 | If you were made the team lead of a group of 4 freshers like yourself, how would you organize the team and assign work? |
| 2 | A junior colleague comes to you saying they don't understand a concept and are embarrassed to ask the manager. How do you handle it? |
| 3 | You notice two teammates are not talking to each other after an argument, and it's affecting the team's output. What would you do? |
| 4 | How do you give feedback to someone whose code quality is poor — without offending them or damaging the relationship? |
| 5 | A team member consistently takes credit for ideas that were discussed as a group. How would you address this? |
| 6 | You're paired with a senior developer who is technically great but dismissive of your suggestions because you're a fresher. How do you earn their respect? |
| 7 | How would you onboard a new joiner to your project if your manager asked you to help them settle in during their first week? |
| 8 | You realize your manager is wrong about a technical approach, but they seem confident. How and when do you bring it up? |

---

## 4. STRESS MANAGEMENT & HANDLING PRESSURE

| # | Question |
|---|---------|
| 1 | During your CDAC exams, you had multiple subjects and project deadlines in the same week. How did you manage everything? |
| 2 | You've been working on a feature for 3 days and just realized your entire approach is wrong — you have to start over, and the deadline is in 2 days. What do you do? |
| 3 | Your manager assigns you an urgent task at 5 PM that needs to be done by tomorrow morning. You had personal plans for the evening. How do you handle it? |
| 4 | You're in a client demo and the application crashes in front of everyone. The room goes silent. What's your immediate response? |
| 5 | Two different managers assign you two different urgent tasks on the same day, both claiming theirs is top priority. How do you decide what to work on? |
| 6 | You've been debugging a production issue for 6 hours with no progress. Your team lead checks in every hour asking for updates. How do you handle the pressure? |
| 7 | How do you maintain work quality when you're working on something repetitive or boring — like testing 200 records manually? |
| 8 | What do you do to recharge after a particularly stressful week at work? Do you have any personal strategies for managing stress? |

---

## 5. PERSONAL HANDLING & WORK ETHICS

| # | Question |
|---|---------|
| 1 | You accidentally pushed buggy code to production and no one noticed yet. Do you disclose it immediately or try to fix it quietly first? What's your approach? |
| 2 | Your colleague shares a shortcut that technically works but skips proper testing and code review. It saves 2 days. Do you take the shortcut? Why or why not? |
| 3 | You promised a delivery by Friday, but by Wednesday you realize it's not possible. How and when do you communicate this? |
| 4 | A client/vendor offers you a small personal gift after a successful project delivery. Your company policy says no gifts above ₹500. The gift is worth ₹2,000. What do you do? |
| 5 | You overhear a colleague discussing confidential customer data on a phone call in the cafeteria. What action do you take, if any? |
| 6 | Your friend at the same company asks you to share your login credentials "just for 5 minutes" to check something. How do you respond? |
| 7 | You're assigned a task that's below your skill level — something very basic and tedious. How do you approach it? |
| 8 | You've been at the company for 6 months and haven't received any appreciation or recognition despite good work. How do you handle this feeling? |
| 9 | A coworker takes a longer lunch break daily and no one seems to notice. Does it bother you? Would you do the same? |
| 10 | You find an error in a report that your senior prepared and submitted to the client. The senior doesn't know about the error. What do you do? |

---

## 6. SYSTEM DESIGN THINKING

| # | Question |
|---|--------|
| 1 | Bajaj Finserv wants to build a simple "EMI Calculator" feature on their website. A customer enters loan amount, interest rate, and tenure — and sees the monthly EMI. How would you design this? What components/layers would you think about? |
| 2 | You're asked to design a basic notification system that sends SMS and email alerts when a customer's EMI payment is due. Draw out (verbally) the high-level components and how they'd interact. |
| 3 | The company wants an internal tool where managers can see all loan applications assigned to their team, filter by status, and reassign them. What screens/pages would this tool have, and what data would each show? |
| 4 | Imagine you need to design a customer feedback system — after every loan disbursement, the customer rates their experience (1-5 stars + comment). How would you store this data, display it, and make it useful for the business? |
| 5 | You have a customer support ticketing system. Currently it's a single page with 10,000 tickets and no filters. The support team is frustrated. How would you redesign the interface? What filters/features would you add? |
| 6 | If you were asked to design a "Loan Eligibility Checker" — the user inputs their salary, existing EMIs, and credit score, and the system says which loan products they qualify for — how would you break this into modules? |
| 7 | A branch manager wants a dashboard showing: total loans today, pending approvals, top-performing agents, and overdue EMIs. How would you structure the data sources and layout for this dashboard? |
| 8 | You need to design a document upload system for loan applications — customers upload PAN, Aadhaar, salary slips. What would you consider: storage, file types, size limits, security, and how does the loan officer review them? |

---

## 7. REQUIREMENT GATHERING & ANALYSIS

| # | Question |
|---|--------|
| 1 | The business team says: "We need a report." That's all they tell you. What questions do you ask before you even open your laptop? |
| 2 | A product owner says: "Build a feature where customers can track their loan application status in real time." What clarifying questions would you ask to turn this vague request into actionable requirements? |
| 3 | You're in a meeting where the marketing team, the tech lead, and the compliance officer each want different things from the same feature. How do you identify what's actually needed vs. what's a nice-to-have? |
| 4 | The operations team says: "The loan approval process is too slow." Before jumping to solutions, how do you investigate this problem? What data/information would you gather first? |
| 5 | A stakeholder asks for a change mid-sprint: "Add an export-to-PDF button on every report." The team is already at capacity. How do you handle this requirement change? |
| 6 | You receive a 20-page requirement document for a new module. How do you approach reading it — do you read everything first, or do you have a different strategy to extract what matters? |
| 7 | The customer support team says: "We need a way to flag high-priority complaints." What does "high-priority" mean to them? What questions would you ask to define this precisely? |
| 8 | A client says "Make the application faster." How do you convert this subjective statement into measurable, testable requirements? |

---

## 8. PRODUCT THINKING & MANAGEMENT

| # | Question |
|---|--------|
| 1 | If you were the product manager for Bajaj Finserv's mobile app and could add ONE new feature, what would it be and why? How would you decide if it's worth building? |
| 2 | You have 3 feature requests: (A) Dark mode for the app, (B) Instant loan pre-approval notification, (C) Chatbot for FAQs. You can only build one this quarter. How do you prioritize? What factors do you consider? |
| 3 | The company launches a new feature — "Instant Personal Loan in 5 Minutes." After 1 month, only 2% of visitors are completing the application. How would you analyze what's going wrong? |
| 4 | A competitor launches a feature that your app doesn't have. The CEO says "Build the same thing immediately." Is this always the right approach? How would you evaluate whether to build it? |
| 5 | You built an internal tool for the loan processing team. After launch, they say: "It's too complicated, we still use Excel." What went wrong in the process, and how do you fix it? |
| 6 | How would you measure the success of a newly launched feature? What 3-4 metrics would you track, and how long would you wait before calling it a success or failure? |
| 7 | The business team wants to target customers who abandoned their loan application midway. How would you approach this — what data do you need, what would you build, and how would you re-engage them? |
| 8 | You notice that 40% of customers drop off at the document upload step during the loan application. What could be the possible reasons, and what changes would you suggest to improve completion rates? |

---

## EVALUATION GRID

| Parameter | Score (1-5) | Notes |
|-----------|:-----------:|-------|
| Functional / Domain Awareness | | |
| Teamwork & Collaboration | | |
| People Management & Interpersonal | | |
| Stress Management & Composure | | |
| Personal Ethics & Work Handling | | |
| System Design Thinking | | |
| Requirement Gathering & Analysis | | |
| Product Thinking & Management | | |
| Communication Clarity | | |
| **Overall HR Score** | **/5** | |

**Verdict:** ☐ Recommended &nbsp;&nbsp; ☐ On Hold &nbsp;&nbsp; ☐ Not Recommended

**Interviewer:** _________________ &nbsp;&nbsp; **Date:** __ / 03 / 2026

---

### Scoring Guide
| Score | Meaning |
|:-----:|---------|
| **5** | Exceptional — Mature, well-articulated, shows leadership potential |
| **4** | Good — Clear thinking, practical approach, confident |
| **3** | Average — Acceptable answers but lacks depth or specificity |
| **2** | Below Average — Vague, generic responses, limited self-awareness |
| **1** | Poor — No relevant answer, red flags in attitude or ethics |

### 🔴 Red Flags to Watch For
- Blames others consistently, takes no ownership
- "I'll just do what I'm told" — zero initiative
- Cannot name a single real example from their experience
- Dismissive about teamwork ("I prefer working alone always")
- Ethics questions answered with shortcuts/dishonesty
- No stress management strategy ("I don't get stressed" = likely unaware)
- Zero knowledge about Bajaj Finserv or financial services domain
- Cannot think beyond code — no awareness of users, business impact, or product decisions
- Jumps to solutions without asking a single clarifying question
- No ability to break a problem into smaller parts or components
