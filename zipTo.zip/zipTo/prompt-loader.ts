/**
 * Prompt template loader
 * Reads the system-prompt.md template from disk and replaces placeholders.
 * Templates are cached in memory after first load to avoid repeated disk I/O.
 *
 * Supported placeholders:
 *   {{KB_PROJECT_NAME}} — from env / KB service
 *   {{CORE_CONTEXT}}    — injected core file contents from KB service
 */

import { readFileSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));

// ─── Template Cache ────────────────────────────────────────────────────────────
const templateCache = new Map<string, string>();

function readTemplate(filename: string, fallback: string): string {
  const cached = templateCache.get(filename);
  if (cached !== undefined) return cached;

  const templatePath = join(__dirname, filename);
  let content: string;
  try {
    content = readFileSync(templatePath, "utf-8");
  } catch (err: any) {
    console.error(`[prompt-loader] Failed to read ${filename}: ${err.message}`);
    content = fallback;
  }

  templateCache.set(filename, content);
  return content;
}

/** Load and assemble the system prompt template with given values. */
export function loadSystemPrompt(values: {
  projectName: string;
  coreContext: string;
}): string {
  const template = readTemplate(
    "system-prompt.md",
    `You are a helpful assistant for **{{KB_PROJECT_NAME}}**.\n\n{{CORE_CONTEXT}}`
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{CORE_CONTEXT\}\}/g, values.coreContext);
}

/** Load and assemble the UD analyst system prompt template with given values. */
export function loadUDSystemPrompt(values: {
  projectName: string;
  coreContext: string;
}): string {
  const template = readTemplate(
    "ud-system-prompt.md",
    `You are a UD Analyst for **{{KB_PROJECT_NAME}}**. ` +
      `Create Understanding Documents through iterative questioning and drafting.\n\n{{CORE_CONTEXT}}`
  );

  const udTemplate = readTemplate(
    "ud-template.md",
    "(UD template file not found — use your best judgment for structure, " +
      "covering: Summary, Requirements, Data Mapping, Business Rules, Acceptance Criteria, " +
      "Affected Components, Prerequisites, Deployment Order, Assumptions, Effort Estimate)"
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{CORE_CONTEXT\}\}/g, values.coreContext)
    .replace(/\{\{UD_TEMPLATE\}\}/g, udTemplate);
}

/** Load and assemble the SDLC Agent system prompt template with given values. */
export function loadSDLCSystemPrompt(values: {
  projectName: string;
  coreContext: string;
}): string {
  const template = readTemplate(
    "sdlc-system-prompt.md",
    `You are an SDLC Agent for **{{KB_PROJECT_NAME}}**. ` +
      `Fetch Azure DevOps work items, create Understanding Documents, and attach them back.\n\n{{CORE_CONTEXT}}`
  );

  const udTemplate = readTemplate(
    "ud-template.md",
    "(UD template file not found — use your best judgment for UD structure)"
  );

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{CORE_CONTEXT\}\}/g, values.coreContext)
    .replace(/\{\{UD_TEMPLATE\}\}/g, udTemplate);
}
