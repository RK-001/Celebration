/**
 * Express server entry point
 * Provides REST + SSE endpoints for file summarization via Copilot SDK.
 */
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Load .env from monorepo root (../../ relative to apps/server/)
const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, "../../../.env") });

import express from "express";
import cors from "cors";
import helmet from "helmet";
import summarizeRouter from "./routes/summarize.js";
import chatRouter from "./routes/chat.js";
import { stopCopilotClient, warmUpCopilotClient } from "./copilot.js";
import { initializeKnowledgeBase } from "./knowledgeBase.js";
import { startSessionCleanup, destroyAllSessions } from "./chatAgent.js";
import { authenticate, apiLimiter } from "./middleware/index.js";
import { azureDevOps } from "./azureDevOps.js";

const PORT = Number(process.env.SERVER_PORT) || 4000;

const app = express();

// ── Security middleware ────────────────────────────────────────────────────────
app.use(helmet());                                          // Security headers
app.use(cors({
  origin: process.env.WEB_ORIGIN || "http://localhost:3000",
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type", "x-api-key", "Authorization"],
}));
app.use(express.json({ limit: "100kb" }));                  // Body size limit
app.use(apiLimiter);                                        // Global rate limit

// ── Authentication (all /api routes) ───────────────────────────────────────────
app.use("/api", authenticate);

// ── Routes ─────────────────────────────────────────────────────────────────────
app.use("/api/summarize", summarizeRouter);
app.use("/api/chat", chatRouter);

// Health check (behind auth — use /healthz for unauthenticated probe)
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Unauthenticated health probe for load balancers / k8s
app.get("/healthz", (_req, res) => {
  res.json({ status: "ok" });
});

// Start
const server = app.listen(PORT, async () => {
  console.log(`\n🚀 SDLC-Copilot server running at http://localhost:${PORT}`);
  console.log(`   POST /api/summarize        — full JSON response`);
  console.log(`   POST /api/summarize/stream  — SSE streaming response`);
  console.log(`   POST /api/chat/stream       — KB chat streaming (NEW)`);
  console.log(`   GET  /api/chat/status       — KB status (NEW)`);
  console.log(`   GET  /api/health            — health check\n`);

  // Pre-warm the Copilot client so the first request isn't slow
  warmUpCopilotClient();

  // Initialize knowledge base (fetch core files from GitHub)
  await initializeKnowledgeBase();

  // Validate Azure DevOps configuration for SDLC Agent mode
  azureDevOps.validateConfig();

  // Start idle session cleanup (reap sessions idle > 30 min)
  startSessionCleanup(30 * 60 * 1000);
});

// Graceful shutdown
async function shutdown() {
  console.log("\n🛑 Shutting down...");
  await destroyAllSessions();
  await stopCopilotClient();
  server.close(() => process.exit(0));
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
