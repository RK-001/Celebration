/**
 * Chat Agent
 *
 * Manages persistent Copilot SDK sessions keyed by a composite key:
 *   `${userId}:${clientSessionId}:${mode}`
 *
 * Mode "chat" — KB knowledge base assistant (fetch_kb_file tool)
 * Mode "ud"   — UD Analyst (fetch_kb_file + create_ud_file tools)
 *
 * Security:
 *   - Sessions are bound to userId (from auth middleware) to prevent hijacking
 *   - Max total sessions enforced to prevent memory exhaustion
 *   - Per-user session limits enforced
 *
 * Each session retains full conversation history in the SDK layer — only
 * the current message is passed per turn via session.send({ prompt }).
 */

import { approveAll, defineTool, type CopilotSession } from "@github/copilot-sdk";
import { getConfiguredModel, getCopilotClient } from "./copilot.js";
import { knowledgeBase } from "./knowledgeBase.js";
import { loadSystemPrompt, loadUDSystemPrompt, loadSDLCSystemPrompt } from "./prompts/prompt-loader.js";
import { azureDevOps } from "./azureDevOps.js";

// ─── Config ────────────────────────────────────────────────────────────────────

const MAX_TOTAL_SESSIONS = Number(process.env.MAX_TOTAL_SESSIONS) || 500;
const MAX_SESSIONS_PER_USER = Number(process.env.MAX_SESSIONS_PER_USER) || 10;

// ─── Session Map ───────────────────────────────────────────────────────────────

interface SessionEntry {
  session: CopilotSession;
  lastUsedAt: number; // ms timestamp
  userId: string;     // bound identity from auth middleware
}

/**
 * Composite key format: `${userId}:${clientSessionId}:${mode}`
 * Ensures sessions are scoped to the authenticated user.
 */
const sessions = new Map<string, SessionEntry>();

// ─── Shared Tool Builders ─────────────────────────────────────────────────────

/** Build the fetch_kb_file tool — shared by both "chat" and "ud" modes */
function buildFetchKBFileTool() {
  return defineTool("fetch_kb_file", {
    description:
      "Fetch the content of a file from the knowledge base repository. " +
      "Use the INDEX file to find which file path corresponds to a topic, " +
      "then call this tool to retrieve its full content.",
    parameters: {
      type: "object",
      properties: {
        filePath: {
          type: "string",
          description:
            "Relative path to the file within the KB repository " +
            "(e.g. 'auth-module.md', 'modules/payments.md'). " +
            "Do not include leading slashes.",
        },
      },
      required: ["filePath"],
    },
    handler: async (args: unknown) => {
      const { filePath } = args as { filePath: string };
      console.log(`[chatAgent] Tool: fetch_kb_file("${filePath}")`);
      try {
        const content = await knowledgeBase.fetchKBFileContent(filePath);
        return content;
      } catch (err: any) {
        console.error(`[chatAgent] fetch_kb_file error: ${err.message}`);
        return `Error fetching "${filePath}": ${err.message}`;
      }
    },
  });
}

/**
 * Build the create_ud_file tool — used in "ud" mode only.
 * The handler returns a success string to the LLM.
 * The actual file content is captured by the route layer from the
 * tool.execution_start event and emitted as a ud_file_ready SSE event.
 */
function buildCreateUDFileTool() {
  return defineTool("create_ud_file", {
    description:
      "Create the final Understanding Document (UD) file after the user has explicitly approved the draft. " +
      "ONLY call this tool after the user says 'approved', 'looks good', 'LGTM', 'finalize', or similar. " +
      "The file will be delivered to the user as a downloadable Markdown file.",
    parameters: {
      type: "object",
      properties: {
        filename: {
          type: "string",
          description:
            "Filename for the UD (e.g., 'UD_TICKET-123.md'). " +
            "Use the ticket ID from the requirement if available, otherwise use a descriptive name.",
        },
        content: {
          type: "string",
          description: "The complete, final UD content in Markdown format.",
        },
      },
      required: ["filename", "content"],
    },
    handler: async (args: unknown) => {
      const { filename } = args as { filename: string; content: string };
      console.log(`[chatAgent] Tool: create_ud_file("${filename}")`);
      // The route layer intercepts this via tool.execution_start and emits ud_file_ready.
      return `UD file "${filename}" has been created and sent to the user for download.`;
    },
  });
}

/** Build the fetch_azure_work_item tool — used in "sdlc" mode */
function buildFetchAzureWorkItemTool() {
  return defineTool("fetch_azure_work_item", {
    description:
      "Fetch a work item from Azure DevOps by its numeric ID. " +
      "Returns structured data including title, description, acceptance criteria, state, " +
      "work item type, and metadata. Call this immediately when the user provides a Work Item ID.",
    parameters: {
      type: "object",
      properties: {
        workItemId: {
          type: "number",
          description: "The numeric Azure DevOps Work Item ID (e.g. 1234).",
        },
        project: {
          type: "string",
          description:
            "Optional Azure DevOps project name. Omit to use the default project (ADO_PROJECT env var).",
        },
      },
      required: ["workItemId"],
    },
    handler: async (args: unknown) => {
      const { workItemId, project } = args as { workItemId: number; project?: string };
      console.log(`[chatAgent] Tool: fetch_azure_work_item(${workItemId})`);
      try {
        const workItem = await azureDevOps.fetchWorkItem(workItemId, project);
        // Return JSON so the route layer can extract it for the work_item_loaded SSE event
        // and the LLM has the full structured data to populate the UD.
        return JSON.stringify(workItem);
      } catch (err: any) {
        console.error(`[chatAgent] fetch_azure_work_item error: ${err.message}`);
        return `Error fetching Work Item #${workItemId}: ${err.message}`;
      }
    },
  });
}

/**
 * Build the attach_ud_to_work_item tool — used in "sdlc" mode only.
 * Called ONLY after explicit user approval and AFTER create_ud_file has been called.
 */
function buildAttachUDToWorkItemTool() {
  return defineTool("attach_ud_to_work_item", {
    description:
      "Upload the Understanding Document to Azure DevOps and link it to the work item. " +
      "ONLY call this tool after: (1) the user explicitly approves the UD, and " +
      "(2) create_ud_file has already been called. Never call this before create_ud_file.",
    parameters: {
      type: "object",
      properties: {
        workItemId: {
          type: "number",
          description: "The numeric Azure DevOps Work Item ID to attach the UD to.",
        },
        filename: {
          type: "string",
          description:
            "The UD filename (e.g. 'UD_WI-1234.md'). Must match the filename used in create_ud_file.",
        },
        content: {
          type: "string",
          description: "The complete UD content in Markdown format.",
        },
        project: {
          type: "string",
          description:
            "Optional Azure DevOps project name. Omit to use the default project (ADO_PROJECT).",
        },
      },
      required: ["workItemId", "filename", "content"],
    },
    handler: async (args: unknown) => {
      const { workItemId, filename, content, project } = args as {
        workItemId: number;
        filename: string;
        content: string;
        project?: string;
      };
      console.log(`[chatAgent] Tool: attach_ud_to_work_item(${workItemId}, "${filename}")`);
      try {
        const { attachmentUrl } = await azureDevOps.attachUDToWorkItem(
          workItemId,
          filename,
          content,
          project,
        );
        const org = process.env.ADO_ORG || "";
        const proj = project || process.env.ADO_PROJECT || "";
        const webUrl =
          `https://dev.azure.com/${encodeURIComponent(org)}` +
          `/${encodeURIComponent(proj)}/_workitems/edit/${workItemId}`;
        // Return JSON so the route layer can emit ud_attached SSE event to the frontend.
        return JSON.stringify({ workItemId, attachmentUrl, webUrl });
      } catch (err: any) {
        console.error(`[chatAgent] attach_ud_to_work_item error: ${err.message}`);
        return `Error attaching UD to Work Item #${workItemId}: ${err.message}`;
      }
    },
  });
}

// ─── Session Lifecycle ─────────────────────────────────────────────────────────

/**
 * Get an existing session or create a new one.
 * Sessions are keyed by `${userId}:${sessionId}:${mode}` so they are bound to the
 * authenticated identity and cannot be hijacked.
 *
 * Enforces:
 *   - Max total sessions (returns error when at global capacity)
 *   - Max sessions per user
 *   - Evicts the oldest session for the user when per-user limit hit
 */
export async function getOrCreateSession(
  sessionId: string,
  mode: "chat" | "ud" | "sdlc" = "chat",
  userId: string = "dev"
): Promise<CopilotSession> {
  const sessionKey = `${userId}:${sessionId}:${mode}`;

  const existing = sessions.get(sessionKey);
  if (existing) {
    if (existing.userId !== userId) {
      throw new Error("Session access denied");
    }
    existing.lastUsedAt = Date.now();
    console.log(`[chatAgent] Reusing session ${sessionKey}`);
    return existing.session;
  }

  // ── Enforce capacity limits ──────────────────────────────────────────────
  if (sessions.size >= MAX_TOTAL_SESSIONS) {
    // Evict the globally LRU session to make room
    let oldestKey: string | null = null;
    let oldestTime = Infinity;
    for (const [key, entry] of sessions.entries()) {
      if (entry.lastUsedAt < oldestTime) {
        oldestTime = entry.lastUsedAt;
        oldestKey = key;
      }
    }
    if (oldestKey) {
      console.log(`[chatAgent] Global session cap reached — evicting ${oldestKey}`);
      await destroySession(oldestKey);
    }
  }

  // Enforce per-user limit
  const userSessions = [...sessions.entries()].filter(([, e]) => e.userId === userId);
  if (userSessions.length >= MAX_SESSIONS_PER_USER) {
    // Evict the LRU session for this user
    const lru = userSessions.reduce((a, b) => (a[1].lastUsedAt < b[1].lastUsedAt ? a : b));
    console.log(`[chatAgent] Per-user cap reached for ${userId} — evicting ${lru[0]}`);
    await destroySession(lru[0]);
  }

  console.log(`[chatAgent] Creating new session ${sessionKey} (mode=${mode})`);

  const client = await getCopilotClient();
  const model = getConfiguredModel();

  const fetchKBFileTool = buildFetchKBFileTool();

  // Common auto-skip for user-input requests (Phase 1/3 — Phase 2 will add a real bridge)
  const onUserInputRequest = async (request: { question: string }) => {
    console.warn("[chatAgent] User input requested (auto-skip):", request.question);
    return { answer: "", wasFreeform: true };
  };

  let session: CopilotSession;

  if (mode === "ud") {
    // ── UD Analyst mode ────────────────────────────────────────────────────────
    const systemPromptContent = loadUDSystemPrompt({
      projectName: knowledgeBase.getProjectName(),
      coreContext: knowledgeBase.getCoreContext(),
    });

    const createUDFileTool = buildCreateUDFileTool();

    session = await client.createSession({
      model,
      streaming: true,
      systemMessage: { mode: "replace", content: systemPromptContent },
      tools: [fetchKBFileTool, createUDFileTool],
      infiniteSessions: { enabled: true },
      onPermissionRequest: approveAll,
      onUserInputRequest,
    });
  } else if (mode === "sdlc") {
    // ── SDLC Agent mode ────────────────────────────────────────────────────────
    const systemPromptContent = loadSDLCSystemPrompt({
      projectName: knowledgeBase.getProjectName(),
      coreContext: knowledgeBase.getCoreContext(),
    });

    const createUDFileTool = buildCreateUDFileTool();
    const fetchAzureWorkItemTool = buildFetchAzureWorkItemTool();
    const attachUDToWorkItemTool = buildAttachUDToWorkItemTool();

    session = await client.createSession({
      model,
      streaming: true,
      systemMessage: { mode: "replace", content: systemPromptContent },
      // fetch_kb_file: KB context during Phase 2 questioning
      // create_ud_file: browser download in Phase 5 step 1
      // fetch_azure_work_item: ADO fetch in Phase 1
      // attach_ud_to_work_item: ADO attachment in Phase 5 step 2
      tools: [fetchKBFileTool, createUDFileTool, fetchAzureWorkItemTool, attachUDToWorkItemTool],
      infiniteSessions: { enabled: true },
      onPermissionRequest: approveAll,
      onUserInputRequest,
    });
  } else {
    // ── KB Chat mode (default) ────────────────────────────────────────────────
    const systemPromptContent = loadSystemPrompt({
      projectName: knowledgeBase.getProjectName(),
      coreContext: knowledgeBase.getCoreContext(),
    });

    session = await client.createSession({
      model,
      streaming: true,
      systemMessage: { mode: "replace", content: systemPromptContent },
      tools: [fetchKBFileTool],
      infiniteSessions: { enabled: true },
      onPermissionRequest: approveAll,
      onUserInputRequest,
    });
  }

  console.log(`[chatAgent] Session created: ${sessionKey} (model=${model})`);
  sessions.set(sessionKey, { session, lastUsedAt: Date.now(), userId });

  return session;
}

/**
 * Destroy a specific session by its composite key and remove it from the map.
 * Called internally by destroyAllSessions and startSessionCleanup with keys
 * obtained directly from sessions.keys() — these are already composite keys.
 */
export async function destroySession(sessionKey: string): Promise<void> {
  const entry = sessions.get(sessionKey);
  if (!entry) return;

  sessions.delete(sessionKey);
  try {
    await entry.session.destroy();
    console.log(`[chatAgent] Session destroyed: ${sessionKey}`);
  } catch (err: any) {
    console.warn(`[chatAgent] Error destroying session ${sessionKey}:`, err.message);
  }
}

/**
 * Destroy all sessions. Called on server shutdown.
 */
export async function destroyAllSessions(): Promise<void> {
  const ids = Array.from(sessions.keys());
  console.log(`[chatAgent] Destroying ${ids.length} sessions...`);
  await Promise.allSettled(ids.map((id) => destroySession(id)));
}

/**
 * Start a periodic cleanup of idle sessions.
 * @param ttlMs - Sessions idle longer than this are destroyed (default: 30 min)
 */
export function startSessionCleanup(ttlMs = 30 * 60 * 1000): NodeJS.Timeout {
  const intervalMs = Math.min(ttlMs, 5 * 60 * 1000); // check at most every 5 min
  const timer = setInterval(async () => {
    const now = Date.now();
    const stale: string[] = [];

    for (const [id, entry] of sessions.entries()) {
      if (now - entry.lastUsedAt > ttlMs) {
        stale.push(id);
      }
    }

    if (stale.length > 0) {
      console.log(`[chatAgent] Cleaning up ${stale.length} idle session(s)`);
      await Promise.allSettled(stale.map((id) => destroySession(id)));
    }
  }, intervalMs);

  // Don't keep the process alive just for cleanup
  timer.unref();
  return timer;
}
