/**
 * Chat routes
 *
 * POST /api/chat/stream — Main chat endpoint (SSE)
 *   Body: { sessionId: string, message: string, mode?: "chat" | "ud" }
 *   Response: SSE stream of ChatStreamEvent objects
 *
 * GET  /api/chat/status — KB status check
 *   Response: { ready, filesLoaded, errors, cacheSize }
 *
 * Security: requests are pre-authenticated by the auth middleware in index.ts.
 * Per-request SSE handlers are unsubscribed on res.close to prevent
 * event leaks across reused persistent sessions.
 */

import { Router, Request, Response } from "express";
import { getOrCreateSession } from "../chatAgent.js";
import { knowledgeBase } from "../knowledgeBase.js";
import { validateChatRequest, streamLimiter, type AuthenticatedRequest } from "../middleware/index.js";

const router = Router();

// ─── SSE Heartbeat Interval (ms) ───────────────────────────────────────────────
const HEARTBEAT_INTERVAL_MS = Number(process.env.SSE_HEARTBEAT_MS) || 20_000;

// ─── Helpers ───────────────────────────────────────────────────────────────────

/** Write a single SSE event to the response */
function sseWrite(res: Response, type: string, data: string): void {
  try {
    res.write(`data: ${JSON.stringify({ type, data })}\n\n`);
  } catch {
    // Ignore write errors on closed responses
  }
}

// ─── POST /api/chat/stream ─────────────────────────────────────────────────────

router.post("/stream", streamLimiter, async (req: Request, res: Response) => {
  const validation = validateChatRequest(req.body);
  if (!validation.valid) {
    return res.status(400).json({ error: validation.error });
  }

  const { sessionId, message, mode } = validation.data;
  const userId = (req as AuthenticatedRequest).userId;

  // Set SSE headers
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const logMsg = message.length > 80 ? message.slice(0, 80) + "..." : message;
  console.log(`[chat/stream] session=${sessionId} mode=${mode} message="${logMsg}"`);

  // Track per-request unsubscribe functions to avoid handler leaks
  const unsubFns: Array<() => void> = [];
  // Correlate toolCallId → label (filePath or "create_ud_file") for tool_complete messages
  const toolCallLabels = new Map<string, string>();
  let finished = false;

  function cleanup() {
    if (unsubFns.length > 0) {
      unsubFns.forEach((fn) => fn());
      unsubFns.length = 0;
    }
  }

  function finish(type: "done" | "error", data = "") {
    if (finished) return;
    finished = true;
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    sseWrite(res, type, data);
    res.end();
    cleanup();
  }

  // ── SSE heartbeat to keep connection alive through proxies ────────────────
  let heartbeatTimer: ReturnType<typeof setInterval> | null = null;

  try {
    const session = await getOrCreateSession(sessionId, mode, userId);

    // Send initial status
    sseWrite(res, "status", "Processing...");

    // Start SSE heartbeat to prevent proxy/LB timeouts
    heartbeatTimer = setInterval(() => {
      try { res.write(": keepalive\n\n"); } catch { /* closed */ }
    }, HEARTBEAT_INTERVAL_MS);

    // ── Register per-request event handlers ─────────────────────────────────
    // session.on() returns an unsubscribe function — always store and call it.

    unsubFns.push(
      session.on("assistant.message_delta", (event) => {
        const delta = event.data.deltaContent;
        if (delta) {
          sseWrite(res, "chunk", delta);
        }
      })
    );

    unsubFns.push(
      session.on("tool.execution_start", (event) => {
        const toolName = (event.data.toolName as string) || "";
        const args = event.data.arguments as Record<string, unknown> | undefined;

        if (toolName === "create_ud_file") {
          // ── UD file creation tool ────────────────────────────────────────
          const filename = (args?.filename as string) || "UD_document.md";
          const content = (args?.content as string) || "";

          toolCallLabels.set(event.data.toolCallId, "create_ud_file");
          console.log(`[chat/stream] Tool start: create_ud_file("${filename}")`);
          sseWrite(res, "tool_start", `Creating UD file "${filename}"...`);

          // Emit the file payload so the frontend can offer a download
          if (filename && content) {
            sseWrite(res, "ud_file_ready", JSON.stringify({ filename, content }));
          }
        } else {
          // ── fetch_kb_file (default) ──────────────────────────────────────
          const filePath = (args?.filePath as string) || toolName;
          toolCallLabels.set(event.data.toolCallId, filePath);
          console.log(`[chat/stream] Tool start: fetch_kb_file("${filePath}")`);
          sseWrite(res, "tool_start", `Fetching ${filePath}...`);
        }
      })
    );

    unsubFns.push(
      session.on("tool.execution_complete", (event) => {
        const { toolCallId, success, result } = event.data;
        const label = toolCallLabels.get(toolCallId) || "file";
        toolCallLabels.delete(toolCallId);

        if (label === "create_ud_file") {
          const msg = success ? "UD file created" : "Failed to create UD file";
          console.log(`[chat/stream] Tool complete: ${msg}`);
          sseWrite(res, "tool_complete", msg);
        } else if (label.startsWith("fetch_azure_work_item:")) {
          // Emit the structured work item to the frontend for the card UI
          if (success && result?.content) {
            try {
              const workItem = JSON.parse(result.content);
              sseWrite(res, "work_item_loaded", JSON.stringify(workItem));
            } catch {
              // Swallow — LLM still received the data
            }
          }
          const workItemId = label.split(":")[1];
          const msg = success
            ? `Loaded Work Item #${workItemId}`
            : `Failed to fetch Work Item #${workItemId}`;
          console.log(`[chat/stream] Tool complete: ${msg}`);
          sseWrite(res, "tool_complete", msg);
        } else if (label.startsWith("attach_ud_to_work_item:")) {
          // Emit the attachment info to the frontend for the confirmation UI
          if (success && result?.content) {
            try {
              const attachInfo = JSON.parse(result.content);
              sseWrite(res, "ud_attached", JSON.stringify(attachInfo));
            } catch {
              // Swallow — attachment still happened
            }
          }
          const workItemId = label.split(":")[1];
          const msg = success
            ? `UD attached to Work Item #${workItemId}`
            : `Failed to attach UD to Work Item #${workItemId}`;
          console.log(`[chat/stream] Tool complete: ${msg}`);
          sseWrite(res, "tool_complete", msg);
        } else {
          const sizeKB = result?.content
            ? (Buffer.byteLength(result.content, "utf8") / 1024).toFixed(1) + " KB"
            : null;
          const msg = success
            ? `Loaded ${label}${sizeKB ? ` (${sizeKB})` : ""}`
            : `Failed to load ${label}`;
          console.log(`[chat/stream] Tool complete: ${msg}`);
          sseWrite(res, "tool_complete", msg);
        }
      })
    );

    unsubFns.push(
      session.on("session.idle", () => {
        console.log(`[chat/stream] Session idle — done`);
        finish("done");
      })
    );

    unsubFns.push(
      session.on("session.error", (event) => {
        const msg = event.data.message || "Unknown session error";
        console.error(`[chat/stream] Session error: ${msg}`);
        finish("error", msg);
      })
    );

    // Unsubscribe on client disconnect (before session.idle fires)
    res.on("close", () => {
      if (heartbeatTimer) clearInterval(heartbeatTimer);
      if (!finished) {
        console.log(`[chat/stream] Client disconnected before done — cleaning up`);
        cleanup();
      }
    });

    // Fire the message — non-blocking, events arrive via handlers above
    await session.send({ prompt: message });
  } catch (err: any) {
    console.error("[chat/stream] Error:", err);
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    cleanup();
    finish("error", err.message || "Internal server error");
  }
});

// ─── GET /api/chat/status ──────────────────────────────────────────────────────

router.get("/status", (_req: Request, res: Response) => {
  const status = knowledgeBase.getStatus();
  res.json(status);
});

export default router;
