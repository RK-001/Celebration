# SDLC Copilot — Project Plan

> Your personal AI assistant that automates daily developer work.
> Say "Start working on US123" and it does the rest — with your approval at every step.

---

## What Is This?

A **chat-based AI tool** that connects to your Azure DevOps and GitHub.
You give it a User Story or Bug ID, and it:

1. **Fetches** the requirement from Azure DevOps
2. **Reads** your codebase / Knowledge Base from GitHub to understand the system
3. **Generates** a UD (Understanding Document)
4. **Shows** you the document — you approve, edit, or reject
5. **Generates** a Technical Document
6. **Shows** you again — you approve, edit, or reject
7. **Attaches** both documents back to the work item in Azure DevOps

**You stay in control.** The agent asks before every action.

---

## How It Looks (User Flow)

```
You:    "Start working on US123"

Agent:  📋 Fetched US123: "Add OTP validation to loan disbursement"
        Description: User should verify OTP before disbursement...
        Acceptance Criteria: 1) OTP via SMS  2) Max 3 retries...

        "Is my understanding correct?"

You:    "Yes, also check the existing OTP service in auth-module"

Agent:  🔍 Searching codebase...
        Found: auth-module/src/otp-service.ts
        Found: loan-api/src/disburse.ts

        📝 Generating UD Document...
        [Shows document preview]

        "Approve / Edit / Reject?"

You:    "Approve"

Agent:  📝 Generating Technical Document...
        [Shows document preview]

        "Approve / Edit / Reject?"

You:    "Approve"

Agent:  ✅ Done! Both documents attached to US123.
        🔗 UD Document: [link]
        🔗 Tech Document: [link]
```

---

## Tech Stack (What We Use)

| Part | Tool | Job |
|------|------|-----|
| **Chat UI** | Next.js + React + Tailwind | Web page where you chat with the agent |
| **Backend** | Node.js + Express + TypeScript | Runs the agent, talks to APIs |
| **AI Brain** | GitHub Copilot SDK | Powers the AI, decides what to do |
| **Code Reading** | GitHub MCP Server | Reads your repos to understand the system |
| **Work Items** | Azure DevOps REST API | Fetches stories/bugs, uploads documents |
| **Real-time Chat** | WebSocket | Streams AI responses word-by-word |
| **Auth (MVP)** | Personal Access Tokens | Simple tokens for DevOps and GitHub |
| **Monorepo** | Turborepo | One repo for frontend + backend |

---

## How It Works (Architecture)

```
  ┌─────────────┐                    ┌─────────────────────┐
  │  FRONTEND   │◄═══ WebSocket ═══►│  BACKEND             │
  │  (Next.js)  │                    │  (Node.js)           │
  │             │                    │                      │
  │  Chat box   │                    │  ┌────────────────┐  │
  │  Doc viewer │                    │  │  Copilot SDK   │  │
  │  Approve btn│                    │  │  (AI Engine)   │  │
  └─────────────┘                    │  └───┬────────┬───┘  │
                                     │      │        │      │
                                     │  ┌───▼────┐ ┌─▼────┐│
                                     │  │ Custom │ │GitHub ││
                                     │  │ Tools  │ │ MCP  ││
                                     │  └───┬────┘ └─┬────┘│
                                     └──────┼────────┼──────┘
                                            │        │
                                    ┌───────▼──┐ ┌───▼──────────┐
                                    │  Azure   │ │  GitHub      │
                                    │  DevOps  │ │  Repos       │
                                    │  (items) │ │  (code)      │
                                    └──────────┘ └──────────────┘
```

**Simple version:**

- You type in the **frontend** (chat UI)
- The **backend** sends your message to the **Copilot SDK** (AI brain)
- The AI brain uses **tools** to fetch data, generate docs, and upload files
- **GitHub MCP** lets the AI read your actual code from GitHub
- **Azure DevOps API** lets the AI fetch work items and attach documents
- Everything streams back to you in **real-time** via WebSocket

---

## Project Folder Structure

```
sdlc-agent/
│
├── .env.example              ← Your tokens and config go here
├── package.json              ← Root project config
├── turbo.json                ← Monorepo task runner
│
├── packages/
│   ├── backend/
│   │   └── src/
│   │       ├── index.ts              ← Server startup
│   │       ├── config.ts             ← Reads .env values
│   │       │
│   │       ├── agent/
│   │       │   ├── session.ts        ← Creates AI sessions
│   │       │   ├── systemPrompt.ts   ← Agent's instructions
│   │       │   └── tools/
│   │       │       ├── fetchWorkItem.ts     ← Get story from DevOps
│   │       │       ├── generateUD.ts        ← Make UD document
│   │       │       ├── generateTechDoc.ts   ← Make Tech document
│   │       │       ├── attachToDevOps.ts    ← Upload docs to DevOps
│   │       │       └── askUser.ts           ← Ask for your approval
│   │       │
│   │       ├── services/
│   │       │   └── azureDevOps.ts    ← Azure DevOps API calls
│   │       │
│   │       ├── websocket/
│   │       │   └── handler.ts        ← Real-time message handling
│   │       │
│   │       └── templates/
│   │           ├── ud-template.md    ← UD document structure
│   │           └── tech-template.md  ← Tech document structure
│   │
│   └── frontend/
│       └── src/
│           ├── app/
│           │   └── page.tsx          ← Main chat page
│           ├── components/
│           │   ├── ChatWindow.tsx    ← Chat message list + input
│           │   ├── MessageBubble.tsx ← Single message display
│           │   ├── DocPreview.tsx    ← Document viewer + editor
│           │   ├── ConfirmCard.tsx   ← Approve / Edit / Reject
│           │   └── WorkflowStatus.tsx← Progress indicator
│           └── hooks/
│               └── useChat.ts       ← WebSocket connection
│
└── docs/
    └── architecture.md
```

---

## Document Templates

### UD (Understanding Document)

| Section | What Goes Here |
|---------|---------------|
| **Original Requirement** | Copied from the Azure DevOps work item (description + acceptance criteria) |
| **Proposed Solution** | AI writes this based on understanding the requirement + your code |
| **Impacted Components** | List of files, modules, services that will change |
| **Technical Details** | High-level approach — what patterns to use, integration points |
| **Assumptions & Risks** | What we're assuming, what could go wrong |
| **Open Questions** | Things the AI is unsure about — you answer these |

### Technical Document

| Section | What Goes Here |
|---------|---------------|
| **Architecture Changes** | What changes in the system design |
| **API Contracts** | New or modified API endpoints with request/response shapes |
| **Database Changes** | Table/column modifications, migrations needed |
| **Code Flow** | Step-by-step: what happens when the feature runs |
| **Test Plan** | What tests to write (unit, integration, edge cases) |
| **Deployment Checklist** | Config changes, feature flags, rollback steps |

---

## Build Steps (MVP — 9 Steps)

### Step 1: Set Up the Project

**What:** Create the monorepo with frontend and backend packages.

**Do:**

- Run `npm init` at root
- Set up Turborepo with `npm workspaces`
- Create `packages/backend` and `packages/frontend` folders
- Add TypeScript config
- Create `.env.example` with these values:
  ```
  ADO_ORG=your-organization
  ADO_PROJECT=your-project
  ADO_PAT=your-azure-devops-token
  GITHUB_TOKEN=your-github-token
  ```

**Test:** `npm install` works, `npx turbo dev` starts both packages.

---

### Step 2: Build Azure DevOps API Service

**What:** Create functions to talk to Azure DevOps.

**Do:** Build 4 functions in `azureDevOps.ts`:

| Function | What It Does |
|----------|-------------|
| `getWorkItem(id)` | Fetches a work item by ID (title, description, acceptance criteria) |
| `getComments(id)` | Fetches discussion comments on a work item |
| `uploadAttachment(name, content)` | Uploads a file, returns its URL |
| `linkAttachment(workItemId, url)` | Links an uploaded file to a work item |

**Test:** Run a script → it prints a real work item's title from your Azure DevOps.

---

### Step 3: Create Document Templates

**What:** Write the Markdown templates for UD and Tech documents.

**Do:** Create `ud-template.md` and `tech-template.md` with the sections listed above. Use `{placeholders}` for values the AI fills in.

**Test:** Open templates in any Markdown viewer — sections look correct.

---

### Step 4: Set Up Copilot SDK

**What:** Initialize the AI engine.

**Do:**

- Install `@github/copilot-sdk`
- Create `session.ts` — connects to Copilot, creates a session
- Connect GitHub MCP Server at `https://api.githubcopilot.com/mcp/` (gives AI access to your repos)
- Register the custom tools (from Step 5)

**Test:** Send "hello" to the session → get a streamed AI response.

---

### Step 5: Build the 5 Custom Tools

**What:** Give the AI specific abilities.

| # | Tool | What The AI Uses It For |
|---|------|------------------------|
| 1 | `fetch_work_item` | "Let me get the details of US123" |
| 2 | `generate_ud` | "I'll create the UD document now" |
| 3 | `generate_tech_doc` | "I'll create the Technical document now" |
| 4 | `attach_to_devops` | "I'll upload this document to Azure DevOps" |
| 5 | `ask_user` | "Is this correct?" / "Do you approve?" |

The AI **automatically decides** which tool to use based on the conversation. You don't call them — the AI does.

**Important:** `ask_user` is the **approval gate**. It pauses the AI, sends a question to you, and waits for your answer before continuing.

**Test:** Trigger each tool manually with test data — all return expected results.

---

### Step 6: Write the System Prompt

**What:** Tell the AI how to behave and what workflow to follow.

**Do:** Write instructions in `systemPrompt.ts`:

```
When the user asks to work on a User Story or Bug:

1. FETCH the work item details
2. SUMMARIZE and ask "Is my understanding correct?"
3. SEARCH the codebase for related code
4. GENERATE the UD document → show preview → ask to approve
5. GENERATE the Tech document → show preview → ask to approve
6. ATTACH both documents to the work item
7. REPORT what was done

Rules:
- Always ask before uploading
- Always show previews before asking approval
- If unsure, ask the user
- Never assume
```

**Test:** Send "start working on US123" → AI follows the 7-step workflow.

---

### Step 7: Build WebSocket Communication

**What:** Create real-time connection between frontend and backend.

**Do:** Set up WebSocket server on the backend that handles these messages:

| From → To | Message | Purpose |
|-----------|---------|---------|
| You → Server | `user_message` | You typed something |
| Server → You | `agent_token` | AI response, word by word |
| Server → You | `confirm_request` | AI asks "Approve?" + shows preview |
| You → Server | `confirm_response` | You click Approve / Edit / Reject |
| Server → You | `status_update` | Shows which step the AI is on |

**Test:** Connect with a WebSocket client → send a message → see tokens stream back.

---

### Step 8: Build the Chat UI

**What:** Create the web page you'll use daily.

**Do:** Build 5 React components:

| Component | What It Shows |
|-----------|-------------|
| `ChatWindow` | Full chat page — messages list + text input at bottom |
| `MessageBubble` | Single message — yours on right (blue), AI on left (gray) |
| `DocPreview` | Generated document in a collapsible card with edit option |
| `ConfirmCard` | Three buttons: ✅ Approve / ✏️ Edit / ❌ Reject |
| `WorkflowStatus` | Progress bar: Fetch → Understand → UD → Tech → Attach → Done |

**Test:** Open `http://localhost:3000` → type a message → see AI response streaming.

---

### Step 9: End-to-End Test

**What:** Test the full workflow with a real work item.

| Action | Expected |
|--------|----------|
| Type "start working on US{real-id}" | Agent shows work item summary |
| Approve understanding | Agent searches your codebase |
| Wait for UD | Document preview appears |
| Click Approve | Agent starts Tech document |
| Wait for Tech Doc | Document preview appears |
| Click Approve | Agent uploads to Azure DevOps |
| Check Azure DevOps | Both docs visible as attachments |

**This completes the MVP.** You now have a working personal SDLC assistant.

---

## What Comes Next (Phase 2)

After MVP works, add these one at a time:

| Feature | What It Does | Effort |
|---------|-------------|--------|
| **Knowledge Base** | Index repos into a vector database (ChromaDB) for deeper code understanding | 2-3 days |
| **Chat History** | Save conversations in SQLite so you can resume ("continue on US123") | 1-2 days |
| **More Commands** | "List my work items", "Update status", "Create a PR" | 1 day each |
| **Better Auth** | Replace PAT tokens with Microsoft Entra ID (enterprise SSO) | 2-3 days |
| **Teams Bot** | Also use it inside Microsoft Teams (alternative to web UI) | 3-4 days |
| **Deploy** | Dockerize and host on Azure | 1-2 days |

---

## Before You Start — Checklist

| # | What You Need | Where To Get It |
|---|--------------|----------------|
| 1 | **Node.js 20+** | `winget install OpenJS.NodeJS.LTS` |
| 2 | **Azure DevOps PAT** | DevOps → Profile → Personal Access Tokens → Scope: Work Items Read & Write |
| 3 | **GitHub PAT** | GitHub → Settings → Developer Settings → Tokens → Scope: `repo`, `copilot` |
| 4 | **Copilot Subscription** | GitHub Copilot Business or Individual plan |
| 5 | **Copilot CLI** | `npm install -g @githubnext/copilot-cli` |
| 6 | **Git** | Already installed (check: `git --version`) |

---

## Key Decisions Summary

| Question | Answer | Why |
|----------|--------|-----|
| Where does the user chat? | **Custom web app** (Next.js) | Full control, no Teams admin needed |
| What powers the AI? | **GitHub Copilot SDK** | Built-in MCP support, custom tools, your existing subscription |
| How to read code? | **GitHub MCP + Vector DB later** | MCP for live access now, deeper search later |
| Document format? | **Markdown** | Simple, readable in Azure DevOps, version-controllable |
| How to authenticate? | **PAT tokens (for now)** | Simplest to start, upgrade to SSO later |
| One repo or many? | **One monorepo** | Easier to develop and share code |
| Build everything at once? | **No, MVP first** | Get core workflow working, then add features |

---

*Last updated: February 23, 2026*
