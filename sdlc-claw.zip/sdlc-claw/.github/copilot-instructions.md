# SDLC Copilot — Workspace Instructions

## Architecture

Turborepo monorepo with two packages:

- **`packages/backend`** — Express + WebSocket (`ws`) server on port **4000**. Orchestrates an AI workflow using the `@github/copilot-sdk`. Integrates with Azure DevOps REST API and GitHub.
- **`packages/frontend`** — Next.js 14 + Tailwind + `react-markdown` app on port **3000**. Communicates with the backend exclusively via WebSocket.

### Key flows
```
User → WebSocket → handler.ts → session.ts (CopilotClient) → tools/ → Azure DevOps / GitHub
                                          ↕ status_update / confirm_request / agent_token events
Frontend: ChatWindow → useChat hook → WebSocket
```

The agent runs in two modes (`AgentMode`): **`sdlc`** (7-step fetch→UD→Tech→attach) and **`us-creator`** (interview→UserStory→BRD). Mode is selected by the frontend and sent in the initial WebSocket message.

## Code Style

- TypeScript 5.7 throughout. Backend is **ESM** (`"type": "module"` in `packages/backend/package.json`) — use `import/export`, not `require()`.
- ESM `__dirname` replacement: `fileURLToPath(import.meta.url)` — see [config.ts](../packages/backend/src/config.ts).
- All agent tools are defined with `defineTool` from `@github/copilot-sdk` and validated with **Zod** schemas. Stateless tools are module-level constants; tools that need WebSocket access use factory functions.
  - Stateless: `export const generateUDTool = defineTool('generate_ud', { ... })`
  - Session-bound: `export function createAskUserTool(session: AgentSession) { return defineTool(...) }` — see [askUser.ts](../packages/backend/src/agent/tools/askUser.ts).
- `types.ts` is **manually kept in sync** between `packages/backend/src/types.ts` and `packages/frontend/src/lib/types.ts`. Edit both when changing shared event types.

## Build and Test

```powershell
# Install (from monorepo root)
npm install

# Dev — run both packages
npm run dev           # uses turbo, starts backend (4000) + frontend (3000)

# Or individually:
# Backend
cd packages/backend
npx tsx src/index.ts          # one-shot run
npm run dev                   # tsx watch (hot reload)
npx tsc --noEmit              # type-check only

# Frontend
cd packages/frontend
npx next dev -p 3000

# Smoke test
cd packages/backend
npm test              # runs src/test/smoke.ts
```

> **Important:** Use `tsx` to run backend TypeScript, **not** `ts-node`. `ts-node` is not configured for ESM.

## Project Conventions

- **Confirmation gate:** The agent MUST call `ask_user` tool before uploading any document to Azure DevOps. The tool sends a `confirm_request` WebSocket event; the frontend renders a `ConfirmCard` and suspends until the user approves/edits/rejects.
- **Phase tracking:** Backend emits `status_update` events (`{ type, phase, message }`) as the agent progresses. Phase → tool name mappings live in `SDLC_TOOL_PHASE_MAP` / `US_CREATOR_TOOL_PHASE_MAP` in [session.ts](../packages/backend/src/agent/session.ts).
- **Singleton `CopilotClient`:** One client per backend process, started once and shared across all WebSocket connections. Managed in [session.ts](../packages/backend/src/agent/session.ts) via `getClient()` / `ensureClientStarted()`.
- **Environment:** `.env` lives at the **monorepo root**. Config is loaded in [config.ts](../packages/backend/src/config.ts) with `path.resolve(__dirname, '../../..', '.env')`. Required vars: `ADO_ORG`, `ADO_PROJECT`, `ADO_PAT`, `GITHUB_TOKEN`. Optional: `PORT` (default 4000), `GITHUB_ORG`, `GITHUB_REPOS`, `COPILOT_CLI_PATH`.

## Integration Points

| System | Access pattern |
|---|---|
| Azure DevOps | REST API via `axios` in [services/azureDevOps.ts](../packages/backend/src/services/azureDevOps.ts), authenticated with `ADO_PAT` (Basic auth, base64) |
| GitHub Copilot | `@github/copilot-sdk` — `CopilotClient` + `defineTool`. CLI bundled by SDK; do not use the VS Code `copilot.bat` path with `spawn()`. |
| Frontend ↔ Backend | WebSocket only (no REST except `/health`). Event types defined in `types.ts`. |

## Security

- `ADO_PAT` and `GITHUB_TOKEN` are read from `.env` (monorepo root) and never committed — `.gitignore` covers `.env`.
- CORS is set to `*` for local development; tighten before any external deployment.
- The Copilot SDK authenticates with `GITHUB_TOKEN` — ensure it has `repo` and Copilot access scopes.
