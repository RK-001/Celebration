# SDLC Copilot � Project Handover

> Pass this file to any new Copilot Agent session to continue exactly where we left off.

---

## What This Project Does

**SDLC Copilot** is a chat-based AI assistant embedded in a web app. A developer types a command like _"Start working on US7834839"_ and the agent:

1. Fetches the User Story / Bug from **Azure DevOps**
2. Asks the developer to confirm understanding
3. Searches the connected **GitHub repositories** for relevant code (via GitHub MCP)
4. Generates a **UD (Understanding Document)** and shows a live preview for approval
5. Generates a **Technical Document** and shows a live preview for approval
6. **Attaches both documents** as files on the Azure DevOps work item
7. Reports completion with direct links

The developer sees a streaming chat UI, approves/edits/rejects documents, and ends up with both documents on the work item � without writing a single line themselves.

---

## Repository Location

```
d:\OneDrive - Bajaj Finance Limited\Documents\RKWork\SDLC Agent\BPR\sdlc-agent\
```

---

## Current Status � All MVP Steps COMPLETE

| Step | Description | Status |
|------|-------------|--------|
| 1 | Turborepo monorepo scaffold | Done |
| 2 | Azure DevOps REST API service | Done and tested |
| 3 | UD + Tech document templates | Done |
| 4 | GitHub Copilot SDK session | Done |
| 5 | 5 custom agent tools | Done |
| 6 | System prompt (7-step workflow) | Done |
| 7 | WebSocket real-time layer | Done |
| 8 | React chat frontend | Done |
| 9 | End-to-end test | NOT YET RUN - do this next |

---

## How to Start the App

**Terminal 1 � Backend:**
```powershell
cd "d:\OneDrive - Bajaj Finance Limited\Documents\RKWork\SDLC Agent\BPR\sdlc-agent\packages\backend"
npx ts-node --transpile-only src/index.ts
```
Starts at http://localhost:4000, WebSocket at ws://localhost:4000

**Terminal 2 � Frontend:**
```powershell
cd "d:\OneDrive - Bajaj Finance Limited\Documents\RKWork\SDLC Agent\BPR\sdlc-agent\packages\frontend"
npx next dev -p 3000
```
Open http://localhost:3000

**Test the ADO connection only:**
```powershell
cd "d:\OneDrive - Bajaj Finance Limited\Documents\RKWork\SDLC Agent\BPR\sdlc-agent\packages\backend"
npx ts-node --transpile-only src/test/smoke.ts 7834839
```

---

## Environment Variables

File: sdlc-agent/.env

```
ADO_ORG=BFLDevOpsOrg
ADO_PROJECT=B2B_Projects
ADO_PAT=<azure-devops-pat>           # Scope: Work Items R/W + Attachments

GITHUB_TOKEN=<github-pat>            # MUST be a real token with repo + copilot scopes
GITHUB_ORG=<your-github-enterprise-org>
GITHUB_REPOS=<repo1>,<repo2>         # Comma-separated repos the MCP agent can read

PORT=4000
NEXT_PUBLIC_BACKEND_WS_URL=ws://localhost:4000
NEXT_PUBLIC_BACKEND_HTTP_URL=http://localhost:4000

# Optional: override Copilot CLI path (default auto-detected)
# COPILOT_CLI_PATH=C:\path\to\copilot.bat
```

WARNING: GITHUB_TOKEN is still set to "test-token" as of last session. A real PAT is required for the Copilot SDK to authenticate.

---

## Known Environment Issues and Fixes

### PowerShell Execution Policy � RESOLVED IN CODE
The Copilot CLI is installed by VS Code as copilot.ps1 + copilot.bat.
The .ps1 file is blocked by corporate policy. The code already bypasses this by calling:

```typescript
cliPath: 'cmd',
cliArgs: ['/c', 'copilot.bat']
```

No manual fix needed � already handled in agent/session.ts.

### gh auth login � Not strictly required
The SDK uses GITHUB_TOKEN env var directly. gh auth login is not required as long as GITHUB_TOKEN is a valid PAT. Recommended as fallback only.

### npm workspaces � Package hoisting
All npm packages are installed at the monorepo root node_modules/ (hoisted by npm workspaces), not inside packages/backend/node_modules/. This is normal � TypeScript resolves them correctly from the root.

---
## Critical Fixes Applied (Latest Session)

These fixes were identified from researching official GitHub Copilot SDK documentation and the awesome-copilot repository, then applied and type-checked (`npx tsc --noEmit` clean).

### 1. `approveAll` Permission Handler (BREAKING CHANGE in SDK v0.1.25+)
**File:** `agent/session.ts`  
**Problem:** SDK v0.1.25+ changed the default permission model to **deny all** tool calls. Without an explicit permission handler, every tool call silently fails.  
**Fix:** Import `approveAll` from `@github/copilot-sdk` and pass it as `onPermissionRequest: approveAll` in `createSession()`.  
**Impact:** Without this fix, none of the 5 custom tools would execute.

### 2. GitHub MCP Server Configuration
**File:** `agent/session.ts`  
**Problem:** The system prompt instructs the agent to "search the codebase" but no MCP server was configured to give it access to GitHub repositories.  
**Fix:** Added `mcpServers.github` block in `createSession()`:  
- `type: 'http'`  
- `url: 'https://api.githubcopilot.com/mcp/'`  
- `tools: ['*']` (all GitHub tools enabled)  
**Impact:** Agent can now search repos during Step 3 (Research) of the workflow.

### 3. Session Hooks (Logging + Error Retry)
**File:** `agent/session.ts`  
**Problem:** No visibility into tool calls or error handling beyond basic console output.  
**Fix:** Added `hooks` block in `createSession()`:  
- `onPreToolUse`: Logs tool name + truncated args, returns `{ permissionDecision: 'allow' }`.  
- `onErrorOccurred`: Logs error context, returns `{ errorHandling: 'retry' }` for automatic retry.  
**Impact:** Better observability and resilience during multi-step workflows.

### 4. Graceful Shutdown
**Files:** `agent/session.ts` + `index.ts`  
**Problem:** Killing the backend left the Copilot CLI child process orphaned.  
**Fix:**  
- Exported `stopCopilotClient()` from session.ts — calls `client.stop()` with `forceStop()` fallback.  
- Added SIGINT/SIGTERM handlers in `index.ts` that call `stopCopilotClient()` then `server.close()`.  
- 5-second forced exit timeout as safety net.  
**Impact:** Clean CLI process cleanup on Ctrl+C or deploy restart.

---
## Full File Structure

```
sdlc-agent/
+-- .env                                         <- credentials (update GITHUB_TOKEN)
+-- package.json                                 <- root monorepo
+-- turbo.json
�
+-- packages/
    +-- backend/
    �   +-- package.json                         <- includes @github/copilot-sdk, zod
    �   +-- src/
    �       +-- index.ts                         <- Express + HTTP server entry point
    �       +-- config.ts                        <- reads all .env values via requireEnv()
    �       +-- types.ts                         <- shared WS message types (WorkflowPhase etc.)
    �       �
    �       +-- agent/
    �       �   +-- session.ts                   <- SDK wiring, streaming, tool registration
    �       �   +-- systemPrompt.ts              <- 7-step workflow instructions (mode: replace)
    �       �   +-- tools/
    �       �       +-- fetchWorkItem.ts         <- fetch_work_item tool
    �       �       +-- generateUD.ts            <- generate_ud tool
    �       �       +-- generateTechDoc.ts       <- generate_tech_doc tool
    �       �       +-- attachToDevOps.ts        <- attach_to_devops tool
    �       �       +-- askUser.ts               <- ask_user tool (pauses AI, awaits user)
    �       �
    �       +-- services/
    �       �   +-- azureDevOps.ts               <- getWorkItem, uploadAttachment, linkAttachment
    �       �
    �       +-- websocket/
    �       �   +-- handler.ts                   <- WS server, AgentSession, confirm gate
    �       �
    �       +-- templates/
    �       �   +-- ud-template.md               <- UD document structure (6 sections)
    �       �   +-- tech-template.md             <- Tech doc structure (7 sections)
    �       �
    �       +-- test/
    �           +-- smoke.ts                     <- ADO connection test
    �
    +-- frontend/
        +-- src/
            +-- app/
            �   +-- page.tsx                     <- main chat page
            �   +-- layout.tsx
            �   +-- globals.css
            +-- components/
            �   +-- ChatWindow.tsx               <- message list + text input
            �   +-- MessageBubble.tsx            <- single message (user right, AI left)
            �   +-- DocPreview.tsx               <- collapsible document viewer with edit
            �   +-- ConfirmCard.tsx              <- Approve / Edit / Reject buttons
            �   +-- WorkflowStatus.tsx           <- step progress indicator
            +-- hooks/
            �   +-- useChat.ts                   <- WebSocket connection + message state
            +-- lib/
                +-- types.ts                     <- shared frontend TS types
```

---

## Architecture � How It All Connects

```
  Browser (http://localhost:3000)
       |  WebSocket ws://localhost:4000
       v
  handler.ts  (WebSocketServer)
       |  AgentSession { ws, pendingConfirm, copilotSession }
       v
  agent/session.ts
       |  CopilotClient  spawns copilot.bat via cmd /c
       |  CopilotSession { model: claude-sonnet-4.6, streaming: true }
       |  5 custom tools registered
       |
       |-- assistant.message_delta  sendToken(ws, chunk)    [streams words]
       |-- session.idle              agent_message_end        [turn complete]
       +-- tool.execution_start     sendStatus(ws, phase)    [progress badge]

  When AI calls ask_user tool:
       |  waitForConfirmation(session, id, title, preview)
       |   sends confirm_request WS event  frontend shows ConfirmCard
       |   Promise pauses AI execution
       |   User clicks Approve/Edit/Reject
       |   confirm_response WS event received
       |   Promise resolves  AI continues
       v
  When AI calls attach_to_devops:
       azureDevOps.uploadAttachment(fileName, Buffer)
       azureDevOps.linkAttachment(workItemId, url)
```

---

## Key Technical Decisions

| Decision | Choice | Reason |
|----------|--------|--------|
| AI provider | GitHub Copilot SDK (@github/copilot-sdk) | Native tool calling, streaming, MCP support |
| Model | claude-sonnet-4.6 | Specified by project owner |
| System prompt mode | replace | Full control of agent behaviour |
| CLI invocation | cmd /c copilot.bat | Corporate PS execution policy blocks .ps1 |
| CopilotClient lifetime | Singleton per backend process | Avoids re-spawning CLI on every message |
| CopilotSession lifetime | One per WebSocket connection | Preserves multi-turn conversation context |
| ask_user pattern | Custom defineTool (closure over AgentSession) | Bridges SDK tool calls to WS confirm_request protocol |
| Tool schema | Zod (z.object) | defineTool API requires Zod schemas |
| Permission model | approveAll (SDK import) | SDK v0.1.25+ denies all by default — this is mandatory |
| GitHub code access | MCP Server (api.githubcopilot.com/mcp/) | SDK-native HTTP MCP, no sidecar needed |
| Error handling | hooks.onErrorOccurred → retry | Auto-retry on transient failures |
| Graceful shutdown | SIGINT/SIGTERM → stopCopilotClient() | Prevents orphaned CLI child processes |
| Document format | Markdown | Renders in Azure DevOps, version-controllable |

---

## WebSocket Message Protocol

### Client to Server
```
{ type: 'user_message', content: string }
{ type: 'confirm_response', id: string, choice: 'approve'|'edit'|'reject', edits?: string }
```

### Server to Client
```
{ type: 'agent_token', token: string }                              <- streaming word
{ type: 'agent_message_end' }                                       <- turn complete
{ type: 'confirm_request', id, title, preview?, question? }         <- approval gate
{ type: 'status_update', phase: WorkflowPhase, message: string }
{ type: 'error', message: string }
{ type: 'agent_ready' }                                             <- sent on WS connect
```

### WorkflowPhase values
idle | fetching | understanding | researching | generating_ud | reviewing_ud | generating_tech | reviewing_tech | attaching | done

---

## The 5 Custom Tools

### fetch_work_item
- Input: { id: number }
- Does: calls azureDevOps.getWorkItem(id), returns Markdown table with title, type, state, description, acceptance criteria
- File: agent/tools/fetchWorkItem.ts

### generate_ud
- Input: { workItemId: number, content: string }
- Does: prepends a dated header to content and returns the full UD document. Does NOT upload.
- File: agent/tools/generateUD.ts

### generate_tech_doc
- Input: { workItemId: number, content: string }
- Does: same pattern as generate_ud for the Tech Doc
- File: agent/tools/generateTechDoc.ts

### attach_to_devops
- Input: { workItemId: number, fileName: string, content: string, docType: 'UD'|'TechDoc' }
- Does: Buffer.from(content) -> uploadAttachment() -> linkAttachment() -> returns URL
- File: agent/tools/attachToDevOps.ts
- NEVER called without prior ask_user approval (enforced by system prompt)

### ask_user
- Input: { id: string, title: string, preview?: string, question?: string }
- Does: calls waitForConfirmation(agentSession) which sends confirm_request WS event and BLOCKS AI execution until user clicks Approve/Edit/Reject
- Returns: "User choice: approve" (or edit/reject) + any edits text
- Factory: createAskUserTool(session: AgentSession) � must be called per WebSocket connection
- File: agent/tools/askUser.ts

---

## What To Do Next (Step 9 � End-to-End Test)

1. Update .env � set GITHUB_TOKEN to a real PAT with repo + copilot scopes
2. Start backend (Terminal 1 above)
3. Start frontend (Terminal 2 above)
4. Open http://localhost:3000
5. Type: Start working on US7834839
6. Expected flow:
   - Agent fetches US 7834839 from Azure DevOps, shows summary
   - Asks "Is my understanding correct?" -> Click Approve
   - Agent searches codebase (GitHub MCP)
   - UD document preview appears -> Click Approve
   - Tech document preview appears -> Click Approve
   - Agent calls attach_to_devops twice -> shows both URLs
   - Both files visible as attachments on US 7834839 in Azure DevOps

---

## Phase 2 Backlog (Post-MVP)

| Feature | Effort | Source |
|---------|--------|--------|
| Skills system (SKILL.md modular prompts) | 1 day | Official SDK docs — modular prompt loading |
| Session persistence via `resumeSession()` | 1 day | SDK built-in — resume conversations across reconnects |
| Token usage tracking (`assistant.usage` event) | 0.5 day | SDK event — monitor cost/usage |
| Vector DB (ChromaDB) for deeper code search | 2-3 days | |
| Chat history persistence (SQLite) | 1-2 days | |
| "List my work items", "Update status" commands | 1 day each | |
| Microsoft Entra ID auth (replace PAT tokens) | 2-3 days | |
| Microsoft Teams bot interface | 3-4 days | |
| Docker + Azure deployment | 1-2 days | |

---

## Tool Versions

| Tool | Version |
|------|---------|
| Node.js | v20.12.2 |
| npm | 10.5.0 |
| TypeScript | ^5.7.0 |
| @github/copilot-sdk | ^0.1.26 |
| zod | ^4.3.6 |
| Next.js | 14.x |
| ws (WebSocket) | ^8.18.0 |

---

*Last updated: June 2025 — Critical fixes applied (approveAll, mcpServers, hooks, graceful shutdown)*
