// ──────────────────────────────────────────────
// Shared message types — single source of truth
// Both backend and frontend re-export from here.
// ──────────────────────────────────────────────

// ─── CLIENT → SERVER ──────────────────────────

export interface UserMessageEvent {
  type: 'user_message';
  content: string;
}

export interface ConfirmResponseEvent {
  type: 'confirm_response';
  id: string;
  choice: 'approve' | 'edit' | 'reject';
  edits?: string;
}

export type ClientEvent = UserMessageEvent | ConfirmResponseEvent;

// ─── SERVER → CLIENT ──────────────────────────

export interface AgentTokenEvent {
  type: 'agent_token';
  token: string;
}

export interface AgentMessageEndEvent {
  type: 'agent_message_end';
}

export interface ConfirmRequestEvent {
  type: 'confirm_request';
  id: string;
  title: string;
  preview?: string;
  question?: string;
  options?: string[];
}

export interface StatusUpdateEvent {
  type: 'status_update';
  phase: AnyPhase;
  message: string;
}

export interface ErrorEvent {
  type: 'error';
  message: string;
}

export interface AgentReadyEvent {
  type: 'agent_ready';
  mode?: AgentMode;
}

export type ServerEvent =
  | AgentTokenEvent
  | AgentMessageEndEvent
  | ConfirmRequestEvent
  | StatusUpdateEvent
  | ErrorEvent
  | AgentReadyEvent;

// ─── AGENT MODES ──────────────────────────────

export type AgentMode = 'sdlc' | 'us-creator';

// ─── WORKFLOW PHASES ──────────────────────────

export type WorkflowPhase =
  | 'idle'
  | 'fetching'
  | 'understanding'
  | 'researching'
  | 'generating_ud'
  | 'reviewing_ud'
  | 'generating_tech'
  | 'reviewing_tech'
  | 'attaching'
  | 'done';

// ─── US CREATOR PHASES ────────────────────────

export type USCreatorPhase =
  | 'idle'
  | 'interviewing'
  | 'refining_us'
  | 'reviewing_us'
  | 'generating_brd'
  | 'reviewing_brd'
  | 'done';

export type AnyPhase = WorkflowPhase | USCreatorPhase;

// ─── WORK ITEM (shared shape) ─────────────────

export interface WorkItemSummary {
  id: number;
  type: string;
  title: string;
  description: string;
  acceptanceCriteria: string;
  state: string;
  assignedTo: string;
  url: string;
}
