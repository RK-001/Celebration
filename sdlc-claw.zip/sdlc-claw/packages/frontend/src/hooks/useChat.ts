'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AgentMode,
  AnyPhase,
  ServerEvent,
} from '@/lib/types';

// ──────────────────────────────────────────────
// Message types for the UI
// ──────────────────────────────────────────────

export interface ChatMessage {
  id: string;
  role: 'user' | 'agent';
  content: string;           // Markdown string
  isStreaming?: boolean;
}

export interface ConfirmRequest {
  id: string;
  title: string;
  preview?: string;
  question?: string;
}

// ──────────────────────────────────────────────
// Welcome messages per mode
// ──────────────────────────────────────────────

const WELCOME_MESSAGES: Record<AgentMode, string> = {
  sdlc:
    '👋 **SDLC Copilot ready!**\n\n' +
    'Tell me which work item to start:\n' +
    '- `"Start working on US123"`\n' +
    '- `"Work on Bug456"`\n\n' +
    'I\'ll fetch the details, understand the requirement, generate documents, and attach them back to Azure DevOps — **with your approval at every step.**',
  'us-creator':
    '👋 **User Story Creator ready!**\n\n' +
    'Tell me about the feature or requirement you\'d like to create:\n' +
    '- `"I want to create a user story for adding email notifications"`\n' +
    '- `"Help me define requirements for a new dashboard feature"`\n\n' +
    'I\'ll guide you through a structured interview, generate a **User Story**, review it for quality, and produce a **BRD** — all with your approval at every step.',
};

// ──────────────────────────────────────────────
// Unique ID helper (collision-safe)
// ──────────────────────────────────────────────

function uid(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

// ──────────────────────────────────────────────
// Hook
// ──────────────────────────────────────────────

const WS_URL =
  process.env.NEXT_PUBLIC_BACKEND_WS_URL ?? 'ws://localhost:4000';

const MAX_RECONNECT_DELAY_MS = 30_000;
const MAX_RECONNECT_ATTEMPTS = 15;

export function useChat(mode: AgentMode = 'sdlc') {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [phase, setPhase] = useState<AnyPhase>('idle');
  const [statusMsg, setStatusMsg] = useState('');
  const [pendingConfirm, setPendingConfirm] = useState<ConfirmRequest | null>(null);
  const [connected, setConnected] = useState(false);

  const ws = useRef<WebSocket | null>(null);
  const streamingId = useRef<string | null>(null);
  const reconnectAttempt = useRef(0);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Use a ref for the latest event handler to avoid stale closures
  const handleServerEventRef = useRef<(event: ServerEvent) => void>(() => {});

  handleServerEventRef.current = (event: ServerEvent) => {
    switch (event.type) {
      case 'agent_ready': {
        const readyMode = event.mode ?? mode;
        setMessages([{
          id: 'welcome',
          role: 'agent',
          content: WELCOME_MESSAGES[readyMode] ?? WELCOME_MESSAGES.sdlc,
        }]);
        break;
      }

      case 'agent_token': {
        const token = event.token;
        setMessages((prev) => {
          if (streamingId.current) {
            return prev.map((m) =>
              m.id === streamingId.current
                ? { ...m, content: m.content + token }
                : m
            );
          }
          const id = `agent-${uid()}`;
          streamingId.current = id;
          return [
            ...prev,
            { id, role: 'agent', content: token, isStreaming: true },
          ];
        });
        break;
      }

      case 'agent_message_end': {
        if (streamingId.current) {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === streamingId.current
                ? { ...m, isStreaming: false }
                : m
            )
          );
          streamingId.current = null;
        }
        break;
      }

      case 'confirm_request': {
        setPendingConfirm({
          id: event.id,
          title: event.title,
          preview: event.preview,
          question: event.question,
        });
        break;
      }

      case 'status_update': {
        setPhase(event.phase);
        setStatusMsg(event.message);
        break;
      }

      case 'error': {
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${uid()}`,
            role: 'agent',
            content: `⚠️ **Error:** ${event.message}`,
          },
        ]);
        break;
      }
    }
  };

  // ── WebSocket connection with exponential backoff ───

  const connect = useCallback(() => {
    // Close any existing socket to prevent duplicates
    if (ws.current) {
      // Remove onclose so it doesn't trigger another reconnect
      ws.current.onclose = null;
      ws.current.close();
      ws.current = null;
    }

    const wsUrl = `${WS_URL}?mode=${mode}`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      setConnected(true);
      reconnectAttempt.current = 0; // reset backoff on success
      console.log(`WebSocket connected [mode=${mode}]`);
    };

    socket.onclose = () => {
      setConnected(false);
      // Exponential backoff: 1s → 2s → 4s → … → 30s max
      if (reconnectAttempt.current < MAX_RECONNECT_ATTEMPTS) {
        const delay = Math.min(
          1000 * Math.pow(2, reconnectAttempt.current),
          MAX_RECONNECT_DELAY_MS
        );
        reconnectAttempt.current += 1;
        console.log(`WebSocket closed — reconnecting in ${delay}ms (attempt ${reconnectAttempt.current})`);
        reconnectTimer.current = setTimeout(connect, delay);
      } else {
        console.warn('WebSocket: max reconnect attempts reached');
      }
    };

    socket.onerror = (err) => {
      console.error('WebSocket error:', err);
    };

    socket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data as string) as ServerEvent;
        handleServerEventRef.current(msg);
      } catch (e) {
        console.error('Failed to parse server message:', e);
      }
    };

    ws.current = socket;
  }, [mode]);

  useEffect(() => {
    connect();
    return () => {
      // Clear reconnect timer on unmount
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      if (ws.current) {
        ws.current.onclose = null;
        ws.current.close();
      }
    };
  }, [connect]);

  // ── Send a user message ────────────────────

  const sendMessage = useCallback((content: string) => {
    if (!ws.current || ws.current.readyState !== WebSocket.OPEN) return;

    setMessages((prev) => [
      ...prev,
      { id: `user-${uid()}`, role: 'user', content },
    ]);

    ws.current.send(JSON.stringify({ type: 'user_message', content }));
  }, []);

  // ── Respond to confirm request ─────────────

  const respondToConfirm = useCallback(
    (choice: 'approve' | 'edit' | 'reject', edits?: string) => {
      if (!pendingConfirm || !ws.current) return;
      ws.current.send(
        JSON.stringify({
          type: 'confirm_response',
          id: pendingConfirm.id,
          choice,
          edits,
        })
      );
      setPendingConfirm(null);
    },
    [pendingConfirm]
  );

  return {
    messages,
    phase,
    statusMsg,
    pendingConfirm,
    connected,
    sendMessage,
    respondToConfirm,
    mode,
  };
}
