'use client';
import { useState } from 'react';
import { ChatWindow } from '@/components/ChatWindow';
import { USCreatorChat } from '@/components/USCreatorChat';
import clsx from 'clsx';

type Tab = 'us-creator' | 'sdlc';

const TABS: { key: Tab; label: string; icon: string; description: string }[] = [
  {
    key: 'us-creator',
    label: 'User Story Creation',
    icon: '📝',
    description: 'Create US, Review & Generate BRD',
  },
  {
    key: 'sdlc',
    label: 'SDLC Agent',
    icon: '🤖',
    description: 'UD & Tech Doc from Work Items',
  },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>('us-creator');

  return (
    <main className="h-screen flex flex-col">
      {/* Header */}
      <header className="flex items-center gap-3 px-5 py-3 border-b border-slate-700 bg-slate-900 shrink-0">
        <div className="w-8 h-8 rounded-full bg-sky-500 flex items-center justify-center text-white font-bold text-sm">
          AI
        </div>
        <div className="flex-1">
          <h1 className="font-semibold text-white text-sm leading-tight">SDLC Copilot</h1>
          <p className="text-xs text-slate-400">Your personal SDLC AI assistant</p>
        </div>
      </header>

      {/* Tab bar */}
      <div className="flex border-b border-slate-700 bg-slate-900 shrink-0">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={clsx(
              'flex items-center gap-2 px-5 py-2.5 text-sm font-medium transition-colors relative',
              activeTab === tab.key
                ? 'text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            )}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
            {/* Active indicator */}
            {activeTab === tab.key && (
              <div className={clsx(
                'absolute bottom-0 left-0 right-0 h-0.5',
                tab.key === 'us-creator' ? 'bg-violet-500' : 'bg-sky-500'
              )} />
            )}
          </button>
        ))}
        {/* Tab description */}
        <div className="flex-1 flex items-center justify-end pr-4">
          <span className="text-xs text-slate-500">
            {TABS.find((t) => t.key === activeTab)?.description}
          </span>
        </div>
      </div>

      {/* Tab content — only mount active tab (single WebSocket connection at a time) */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {activeTab === 'us-creator' ? <USCreatorChat /> : <ChatWindow />}
      </div>
    </main>
  );
}
