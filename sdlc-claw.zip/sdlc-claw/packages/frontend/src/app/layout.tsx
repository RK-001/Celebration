import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SDLC Copilot',
  description: 'Your personal AI assistant for daily SDLC work',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="h-screen overflow-hidden bg-background">{children}</body>
    </html>
  );
}
