'use client';
import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface Props {
  title: string;
  content: string;
  /** When provided, shows an edit button that opens an inline editor */
  onEdit?: (newContent: string) => void;
}

export function DocPreview({ title, content, onEdit }: Props) {
  const [expanded, setExpanded] = useState(true);
  const [editing, setEditing] = useState(false);
  const [editValue, setEditValue] = useState(content);
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveEdit = () => {
    onEdit?.(editValue);
    setEditing(false);
  };

  return (
    <div className="mx-4 my-2 rounded-xl border border-slate-600 bg-slate-900 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-sky-400">📄</span>
          <span className="text-sm font-medium text-slate-200">{title}</span>
        </div>
        <div className="flex items-center gap-2">
          {onEdit && !editing && (
            <button
              onClick={() => setEditing(true)}
              className="text-xs text-slate-400 hover:text-slate-200 px-2 py-0.5 rounded border border-slate-600 hover:border-slate-400 transition-colors"
            >
              ✏️ Edit
            </button>
          )}
          <button
            onClick={handleCopy}
            className="text-xs text-slate-400 hover:text-slate-200 px-2 py-0.5 rounded border border-slate-600 hover:border-slate-400 transition-colors"
          >
            {copied ? '✅ Copied' : '📋 Copy'}
          </button>
          <button
            onClick={() => setExpanded((e) => !e)}
            className="text-xs text-slate-400 hover:text-slate-200 px-2 py-0.5 rounded border border-slate-600 hover:border-slate-400 transition-colors"
          >
            {expanded ? '▲ Collapse' : '▼ Expand'}
          </button>
        </div>
      </div>

      {/* Body */}
      {expanded && (
        <div className="p-4 max-h-[400px] overflow-y-auto">
          {editing ? (
            <div className="flex flex-col gap-2">
              <textarea
                className="w-full min-h-[300px] bg-slate-800 text-slate-100 font-mono text-xs p-3 rounded-lg border border-slate-600 focus:outline-none focus:border-sky-500 resize-y"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
              />
              <div className="flex gap-2">
                <button
                  onClick={handleSaveEdit}
                  className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs rounded-lg"
                >
                  Save Changes
                </button>
                <button
                  onClick={() => {
                    setEditValue(content);
                    setEditing(false);
                  }}
                  className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs rounded-lg"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="prose-chat text-sm text-slate-200">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
