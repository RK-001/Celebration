'use client';
import { useEffect, useState } from 'react';
import { DocPreview } from './DocPreview';
import { ConfirmRequest } from '@/hooks/useChat';

interface Props {
  confirm: ConfirmRequest;
  onRespond: (choice: 'approve' | 'edit' | 'reject', edits?: string) => void;
}

export function ConfirmCard({ confirm, onRespond }: Props) {
  const [editedContent, setEditedContent] = useState(confirm.preview ?? '');
  const [showEdit, setShowEdit] = useState(false);

  // Reset edited content when the confirm request changes
  useEffect(() => {
    setEditedContent(confirm.preview ?? '');
  }, [confirm.preview]);

  const handleEdit = (newContent: string) => {
    setEditedContent(newContent);
    setShowEdit(false);
  };

  return (
    <div className="mx-4 my-3 rounded-2xl border border-sky-700 bg-slate-900 overflow-hidden shadow-lg shadow-sky-900/20">
      {/* Title bar */}
      <div className="px-4 py-3 bg-sky-900/40 border-b border-sky-700/60">
        <p className="text-sm font-semibold text-sky-300">{confirm.title}</p>
        {confirm.question && (
          <p className="text-xs text-slate-300 mt-0.5">{confirm.question}</p>
        )}
      </div>

      {/* Document preview (if any) */}
      {confirm.preview && (
        <div className="border-b border-slate-700">
          <DocPreview
            title="Document Preview"
            content={editedContent}
            onEdit={handleEdit}
          />
        </div>
      )}

      {/* Action buttons */}
      <div className="flex items-center gap-2 px-4 py-3 bg-slate-900">
        <button
          onClick={() => onRespond('approve', confirm.preview ? editedContent : undefined)}
          className="flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white text-sm font-medium rounded-lg transition-colors"
        >
          ✅ Approve
        </button>

        {confirm.preview && (
          <button
            onClick={() => onRespond('edit', editedContent)}
            className="flex items-center gap-1.5 px-4 py-2 bg-amber-700 hover:bg-amber-600 text-white text-sm font-medium rounded-lg transition-colors"
          >
            ✏️ Edit & Approve
          </button>
        )}

        <button
          onClick={() => onRespond('reject')}
          className="flex items-center gap-1.5 px-4 py-2 bg-slate-700 hover:bg-red-800 text-slate-300 hover:text-white text-sm font-medium rounded-lg transition-colors"
        >
          ❌ Reject
        </button>
      </div>
    </div>
  );
}
