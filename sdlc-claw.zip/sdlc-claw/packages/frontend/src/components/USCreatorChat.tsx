'use client';
import { useEffect, useRef, useState, KeyboardEvent } from 'react';
import { useChat } from '@/hooks/useChat';
import { MessageBubble } from './MessageBubble';
import { ConfirmCard } from './ConfirmCard';
import { USCreatorStatus } from './USCreatorStatus';
import clsx from 'clsx';

const SUGGESTIONS = [
  'I want to create a user story for a new feature',
  'Help me define requirements for a dashboard',
  'Create a user story for adding email notifications',
];

export function USCreatorChat() {
  const {
    messages,
    phase,
    statusMsg,
    pendingConfirm,
    connected,
    sendMessage,
    respondToConfirm,
  } = useChat('us-creator');

  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, pendingConfirm]);

  const handleSend = () => {
    const text = input.trim();
    if (!text || !connected) return;
    sendMessage(text);
    setInput('');
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Workflow progress bar */}
      <USCreatorStatus phase={phase} statusMsg={statusMsg} />

      {/* Connection status */}
      {!connected && (
        <div className="px-4 py-2 bg-amber-900/40 border-b border-amber-700/60 text-xs text-amber-300 flex items-center gap-2 shrink-0">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          Connecting to US Creator backend...
        </div>
      )}

      {/* Messages list */}
      <div className="flex-1 overflow-y-auto py-2">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center px-8">
            <div className="w-16 h-16 rounded-full bg-violet-900/60 flex items-center justify-center text-3xl mb-4">
              📝
            </div>
            <h2 className="text-slate-300 font-semibold mb-2">User Story Creator</h2>
            <p className="text-slate-500 text-sm max-w-sm">
              Connecting to the backend... Once connected, I will guide you through
              creating a well-defined User Story and BRD.
            </p>
          </div>
        )}

        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}

        {/* Confirmation card appears inline */}
        {pendingConfirm && (
          <ConfirmCard
            confirm={pendingConfirm}
            onRespond={respondToConfirm}
          />
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick suggestions (only when no conversation) */}
      {messages.length <= 1 && connected && (
        <div className="px-4 py-2 flex gap-2 flex-wrap shrink-0">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => { setInput(s); inputRef.current?.focus(); }}
              className="text-xs px-3 py-1.5 rounded-full border border-slate-600 text-slate-400 hover:text-slate-200 hover:border-slate-400 bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Completion callout */}
      {phase === 'done' && (
        <div className="mx-4 mb-2 px-4 py-3 rounded-xl border border-violet-700 bg-violet-900/30 text-sm text-violet-200">
          ✅ <strong>Documents finalized!</strong> You can copy them from the previews above. 
          Switch to the <strong>SDLC Agent</strong> tab to process an existing work item further.
        </div>
      )}

      {/* Input bar */}
      <div className="shrink-0 px-4 py-3 border-t border-slate-700 bg-slate-900">
        <div
          className={clsx(
            'flex items-end gap-2 rounded-xl border bg-slate-800 px-3 py-2 transition-colors',
            connected ? 'border-slate-600 focus-within:border-violet-600' : 'border-slate-700 opacity-60'
          )}
        >
          <textarea
            ref={inputRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={!connected || !!pendingConfirm}
            placeholder={
              pendingConfirm
                ? 'Please respond to the request above first...'
                : connected
                ? 'Describe your feature or requirement... (Enter to send)'
                : 'Connecting...'
            }
            className="flex-1 bg-transparent text-slate-100 text-sm placeholder-slate-500 resize-none focus:outline-none min-h-[24px] max-h-[120px] leading-6"
            style={{ height: 'auto' }}
            onInput={(e) => {
              const el = e.currentTarget;
              el.style.height = 'auto';
              el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
            }}
          />
          <button
            onClick={handleSend}
            disabled={!connected || !input.trim() || !!pendingConfirm}
            className={clsx(
              'shrink-0 w-8 h-8 rounded-lg flex items-center justify-center transition-colors',
              connected && input.trim() && !pendingConfirm
                ? 'bg-violet-600 hover:bg-violet-500 text-white'
                : 'bg-slate-700 text-slate-500 cursor-not-allowed'
            )}
          >
            ↑
          </button>
        </div>
        <p className="text-xs text-slate-600 mt-1 text-center">
          Enter to send · Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}
