'use client';
import clsx from 'clsx';
import { USCreatorPhase, AnyPhase } from '@/lib/types';

const PHASES: { key: USCreatorPhase; label: string }[] = [
  { key: 'interviewing', label: 'Interview' },
  { key: 'refining_us', label: 'User Story' },
  { key: 'reviewing_us', label: 'Review US' },
  { key: 'generating_brd', label: 'BRD' },
  { key: 'reviewing_brd', label: 'Review BRD' },
  { key: 'done', label: 'Done' },
];

const PHASE_ORDER = PHASES.map((p) => p.key);

interface Props {
  phase: AnyPhase;
  statusMsg: string;
}

export function USCreatorStatus({ phase, statusMsg }: Props) {
  if (phase === 'idle') return null;

  const currentIdx = PHASE_ORDER.indexOf(phase as USCreatorPhase);

  return (
    <div className="px-4 py-2 bg-slate-900 border-b border-slate-700 shrink-0">
      {/* Status text */}
      {statusMsg && (
        <p className="text-xs text-violet-400 mb-2 font-medium">{statusMsg}</p>
      )}

      {/* Progress steps */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1">
        {PHASES.map((p, idx) => {
          const isCompleted = currentIdx >= 0 && idx < currentIdx;
          const isActive = currentIdx >= 0 && idx === currentIdx;
          const isPending = currentIdx < 0 || idx > currentIdx;

          return (
            <div key={`${p.key}-${idx}`} className="flex items-center shrink-0">
              <div
                className={clsx(
                  'px-2 py-0.5 rounded text-xs font-medium',
                  isCompleted && 'bg-violet-900 text-violet-300',
                  isActive && 'bg-violet-500 text-white animate-pulse',
                  isPending && 'bg-slate-800 text-slate-500'
                )}
              >
                {isCompleted && '✓ '}{p.label}
              </div>
              {idx < PHASES.length - 1 && (
                <div
                  className={clsx(
                    'w-4 h-px mx-0.5',
                    isCompleted ? 'bg-violet-700' : 'bg-slate-700'
                  )}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
