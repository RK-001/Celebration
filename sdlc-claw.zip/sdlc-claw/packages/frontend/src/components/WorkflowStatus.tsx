'use client';
import clsx from 'clsx';
import { WorkflowPhase, AnyPhase } from '@/lib/types';

const PHASES: { key: WorkflowPhase; label: string }[] = [
  { key: 'fetching', label: 'Fetch' },
  { key: 'understanding', label: 'Understand' },
  { key: 'researching', label: 'Research' },
  { key: 'generating_ud', label: 'UD Doc' },
  { key: 'reviewing_ud', label: 'Review' },
  { key: 'generating_tech', label: 'Tech Doc' },
  { key: 'reviewing_tech', label: 'Review' },
  { key: 'attaching', label: 'Attach' },
  { key: 'done', label: 'Done' },
];

const PHASE_ORDER: string[] = PHASES.map((p) => p.key);

interface Props {
  phase: AnyPhase;
  statusMsg: string;
}

export function WorkflowStatus({ phase, statusMsg }: Props) {
  if (phase === 'idle') return null;

  const currentIdx = PHASE_ORDER.indexOf(phase as string);

  return (
    <div className="px-4 py-2 bg-slate-900 border-b border-slate-700 shrink-0">
      {/* Status text */}
      {statusMsg && (
        <p className="text-xs text-sky-400 mb-2 font-medium">{statusMsg}</p>
      )}

      {/* Progress steps */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1">
        {PHASES.map((p, idx) => {
          const isCompleted = idx < currentIdx;
          const isActive = idx === currentIdx;
          const isPending = idx > currentIdx;

          return (
            <div key={`${p.key}-${idx}`} className="flex items-center shrink-0">
              <div
                className={clsx(
                  'px-2 py-0.5 rounded text-xs font-medium',
                  isCompleted && 'bg-sky-900 text-sky-300',
                  isActive && 'bg-sky-500 text-white animate-pulse',
                  isPending && 'bg-slate-800 text-slate-500'
                )}
              >
                {isCompleted && '✓ '}{p.label}
              </div>
              {idx < PHASES.length - 1 && (
                <div
                  className={clsx(
                    'w-4 h-px mx-0.5',
                    isCompleted ? 'bg-sky-700' : 'bg-slate-700'
                  )}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
