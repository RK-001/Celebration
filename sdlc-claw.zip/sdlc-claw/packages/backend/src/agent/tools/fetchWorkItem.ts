import { defineTool } from '@github/copilot-sdk';
import { z } from 'zod';
import { getWorkItem } from '../../services/azureDevOps';

export const fetchWorkItemTool = defineTool('fetch_work_item', {
  description:
    'Fetch a work item (User Story or Bug) from Azure DevOps by its numeric ID. ' +
    'Returns a formatted summary including title, type, state, description, acceptance criteria, and assignee.',
  parameters: z.object({
    id: z.number().int().positive().describe('The Azure DevOps work item ID (numeric only, e.g. 7834839)'),
  }),
  handler: async ({ id }) => {
    const item = await getWorkItem(id);

    const lines: string[] = [
      `## Work Item #${item.id}: ${item.title}`,
      '',
      `| Field | Value |`,
      `|-------|-------|`,
      `| **Type** | ${item.type} |`,
      `| **State** | ${item.state} |`,
      `| **Priority** | ${item.priority} |`,
      `| **Assigned To** | ${item.assignedTo || 'Unassigned'} |`,
      `| **Area Path** | ${item.areaPath} |`,
      `| **Tags** | ${item.tags || 'None'} |`,
      '',
      '### Description',
      item.description || '*(No description provided)*',
      '',
      '### Acceptance Criteria',
      item.acceptanceCriteria || '*(No acceptance criteria defined)*',
      '',
      `**Azure DevOps Link:** ${item.url}`,
    ];

    return lines.join('\n');
  },
});
