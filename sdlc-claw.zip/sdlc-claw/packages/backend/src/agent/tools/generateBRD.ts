import { defineTool } from '@github/copilot-sdk';
import { z } from 'zod';

export const generateBRDTool = defineTool('generate_brd', {
  description:
    'Generate a formatted Business Requirements Document (BRD) from the provided Markdown content. ' +
    'Returns the complete document with a dated header. Does NOT upload anywhere — ' +
    'always call ask_user to show the preview and get approval before finalizing.',
  parameters: z.object({
    title: z.string().describe('The BRD title (should match the related User Story title)'),
    content: z.string().describe(
      'The complete Markdown content filling all BRD sections: ' +
      '1. Executive Summary, 2. Business Requirements (US + Context + Scope), ' +
      '3. Functional Requirements (FR-1, FR-2...), 4. Non-Functional Requirements, ' +
      '5. High-Level Process Flow, 6. Data Model Considerations, ' +
      '7. Controls & Validations, 8. Error Handling, ' +
      '9. Acceptance Criteria, 10. Dependencies & Risks, 11. Appendices'
    ),
  }),
  handler: async ({ title, content }) => {
    const date = new Date().toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });

    const header = [
      `# Business Requirements Document — ${title}`,
      '',
      `| Property | Value |`,
      `|----------|-------|`,
      `| **Document Version** | 1.0 |`,
      `| **Date** | ${date} |`,
      `| **Author** | US Creator Copilot |`,
      `| **Status** | Draft — Pending Review |`,
      '',
      '---',
      '',
    ].join('\n');

    return header + content;
  },
});
