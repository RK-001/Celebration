import { defineTool } from '@github/copilot-sdk';
import { z } from 'zod';

export const reviewUserStoryTool = defineTool('review_user_story', {
  description:
    'Request a structured quality review of a User Story or BRD document. ' +
    'Returns the document along with a review framework. The AI should then perform ' +
    'the actual analysis and produce a Review Report with a verdict.',
  parameters: z.object({
    document: z.string().describe('The full Markdown content of the document to review'),
    documentType: z.enum(['US', 'BRD']).describe(
      'Type of document: "US" for User Story, "BRD" for Business Requirements Document'
    ),
  }),
  handler: async ({ document, documentType }) => {
    const docLabel = documentType === 'US' ? 'User Story' : 'Business Requirements Document';

    const reviewFramework = documentType === 'US'
      ? [
          `## Review Framework for ${docLabel}`,
          '',
          'Perform a structured quality review using these 5 checks:',
          '',
          '### Check 1: Structural Completeness',
          'Verify all required sections are present and filled:',
          '- Title (US-XXXX format) — Required',
          '- As a / I want / So that — Required',
          '- Business Context — Required',
          '- Acceptance Criteria (Given/When/Then) — Required',
          '- Technical Notes — Required',
          '- Scope (In/Out) — Required',
          '- Metadata (Priority, Complexity) — Recommended',
          '',
          '### Check 2: Acceptance Criteria Quality',
          '- Each AC must be testable (specific, measurable)',
          '- No duplicate ACs',
          '- Negative/edge cases covered',
          '- Boundary conditions addressed',
          '',
          '### Check 3: Terminology Consistency',
          '- Same concept referred to by same name throughout',
          '- No ambiguous or mixed terminology',
          '',
          '### Check 4: Completeness of Scenarios',
          '- Happy path documented',
          '- Error/failure paths documented',
          '- Bulk vs. single scenarios considered',
          '',
          '### Check 5: Gap & Risk Analysis',
          '- Documentation gaps identified',
          '- Assumption risks flagged',
          '- Integration risks noted',
          '',
          '---',
          '',
          '## Document to Review:',
          '',
          document,
        ].join('\n')
      : [
          `## Review Framework for ${docLabel}`,
          '',
          'Perform a structured quality review using these 5 checks:',
          '',
          '### Check 1: Structural Completeness',
          'Verify all required BRD sections are present:',
          '- Executive Summary — Required',
          '- Business Requirements & User Story — Required',
          '- Scope (In/Out) — Required',
          '- Functional Requirements (numbered) — Required',
          '- Non-Functional Requirements — Required',
          '- Process Flow — Required',
          '- Data Model Considerations — Required',
          '- Controls & Validations — Required',
          '- Error Handling — Required',
          '- Acceptance Criteria — Required',
          '- Dependencies & Risks — Required',
          '- Appendices — Recommended',
          '',
          '### Check 2: Requirements Quality',
          '- Each FR is testable and unambiguous',
          '- NFRs have measurable targets',
          '- No duplicate requirements',
          '',
          '### Check 3: Consistency',
          '- BRD aligns with the User Story it references',
          '- Terminology consistent throughout',
          '- Process flow matches textual description',
          '',
          '### Check 4: Technical Feasibility',
          '- Are proposed designs realistic?',
          '- Data model changes are sound',
          '- Error handling covers key scenarios',
          '',
          '### Check 5: Gap & Risk Analysis',
          '- All risks have mitigation strategies',
          '- Open questions are documented',
          '- Dependencies are identified',
          '',
          '---',
          '',
          '## Document to Review:',
          '',
          document,
        ].join('\n');

    return reviewFramework;
  },
});
