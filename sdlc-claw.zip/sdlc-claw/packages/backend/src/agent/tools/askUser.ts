import { defineTool } from '@github/copilot-sdk';
import { z } from 'zod';
import { AgentSession, waitForConfirmation } from '../../websocket/handler';

/**
 * Factory — creates the ask_user tool bound to a specific WebSocket session.
 * Must be created per-connection so the tool has access to the session's
 * WebSocket and pendingConfirm map.
 */
export function createAskUserTool(agentSession: AgentSession) {
  return defineTool('ask_user', {
    description:
      'Pause AI execution and ask the user a question or show a document preview for approval. ' +
      'This is the approval gate — the AI MUST call this before uploading any document. ' +
      'Returns the user\'s choice ("approve", "edit", or "reject") and any edits/feedback they typed.',
    parameters: z.object({
      id: z.string().describe(
        'Unique identifier for this request, e.g. "confirm_understanding", "review_ud", "review_tech"'
      ),
      title: z.string().describe(
        'Short title shown on the confirmation card in the UI, e.g. "Is my understanding correct?"'
      ),
      preview: z.string().optional().describe(
        'Optional document content to render as a preview in the UI (use for document reviews)'
      ),
      question: z.string().optional().describe(
        'The specific question or instruction to show the user'
      ),
    }),
    handler: async ({ id, title, preview, question }) => {
      const result = await waitForConfirmation(
        agentSession,
        id,
        title,
        preview,
        question
      );

      if (result.edits) {
        return `User choice: ${result.choice}\nUser feedback/edits: ${result.edits}`;
      }
      return `User choice: ${result.choice}`;
    },
  });
}
