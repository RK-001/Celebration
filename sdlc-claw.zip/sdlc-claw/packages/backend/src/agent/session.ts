/**
 * Agent session — orchestrates AI workflow using the GitHub Copilot SDK.
 * Supports two modes:
 *   - 'sdlc': Original 7-step SDLC workflow (fetch → UD → Tech Doc → attach)
 *   - 'us-creator': Multi-phase US creation (interview → generate US → review → BRD)
 *
 * Copilot CLI is invoked via copilot.bat (bypasses PowerShell execution policy).
 */
import { CopilotClient, CopilotSession, approveAll } from '@github/copilot-sdk';
import { config } from '../config';
import {
  AgentSession,
  send,
  sendToken,
  sendStatus,
  sendError,
  setMessageProcessor,
} from '../websocket/handler';
import { SYSTEM_PROMPT } from './systemPrompt';
import { US_CREATOR_PROMPT } from './usCreatorPrompt';
import { fetchWorkItemTool } from './tools/fetchWorkItem';
import { generateUDTool } from './tools/generateUD';
import { generateTechDocTool } from './tools/generateTechDoc';
import { attachToDevOpsTool } from './tools/attachToDevOps';
import { createAskUserTool } from './tools/askUser';
import { generateUserStoryTool } from './tools/generateUserStory';
import { generateBRDTool } from './tools/generateBRD';
import { reviewUserStoryTool } from './tools/reviewUserStory';
import { AgentMode, AnyPhase } from '../types';

// ─── Copilot CLI path ──────────────────────────────────────────────────────
const COPILOT_CLI_OVERRIDE = process.env['COPILOT_CLI_PATH'] ?? undefined;

// ─── Singleton CopilotClient ───────────────────────────────────────────────
let copilotClient: CopilotClient | null = null;
let clientStarted = false;

function getClient(): CopilotClient {
  if (!copilotClient) {
    copilotClient = new CopilotClient({
      ...(COPILOT_CLI_OVERRIDE ? { cliPath: COPILOT_CLI_OVERRIDE } : {}),
      ...(config.github.token && config.github.token !== 'test-token'
        ? { githubToken: config.github.token }
        : {}),
    });
  }
  return copilotClient;
}

async function ensureClientStarted(): Promise<CopilotClient> {
  const client = getClient();
  if (!clientStarted) {
    await client.start();
    clientStarted = true;
    console.log('✅ Copilot CLI started successfully');
  }
  return client;
}

// ─── Tool → Phase mapping (per mode) ───────────────────────────────────────
const SDLC_TOOL_PHASE_MAP: Record<string, AnyPhase> = {
  fetch_work_item: 'fetching',
  generate_ud: 'generating_ud',
  generate_tech_doc: 'generating_tech',
  attach_to_devops: 'attaching',
  ask_user: 'understanding',
};

const US_CREATOR_TOOL_PHASE_MAP: Record<string, AnyPhase> = {
  generate_user_story: 'refining_us',
  generate_brd: 'generating_brd',
  review_user_story: 'reviewing_us',
  review_brd: 'reviewing_brd',
  ask_user: 'interviewing',
};

// ─── Mode-aware helpers ────────────────────────────────────────────────────

function getSystemPrompt(mode: AgentMode): string {
  return mode === 'us-creator' ? US_CREATOR_PROMPT : SYSTEM_PROMPT;
}

function getTools(mode: AgentMode, session: AgentSession) {
  const askUser = createAskUserTool(session);
  if (mode === 'us-creator') {
    return [generateUserStoryTool, generateBRDTool, reviewUserStoryTool, askUser];
  }
  return [fetchWorkItemTool, generateUDTool, generateTechDocTool, attachToDevOpsTool, askUser];
}

function getToolPhaseMap(mode: AgentMode): Record<string, AnyPhase> {
  return mode === 'us-creator' ? US_CREATOR_TOOL_PHASE_MAP : SDLC_TOOL_PHASE_MAP;
}

// ─── SDK hook type helpers (minimal shapes) ───────────────────────────────

interface PreToolUseInput {
  toolName: string;
  toolArgs: unknown;
}

interface ErrorOccurredInput {
  errorContext: string;
  error: unknown;
}

// ─── processMessage ────────────────────────────────────────────────────────
export async function processMessage(
  session: AgentSession,
  userMessage: string
): Promise<void> {
  try {
    sendStatus(session.ws, 'idle', 'Connecting to Copilot...');
    const client = await ensureClientStarted();

    if (!session.copilotSession) {
      sendStatus(session.ws, 'idle', 'Initialising AI session...');

      const mode = session.mode;
      const systemPrompt = getSystemPrompt(mode);
      const tools = getTools(mode, session);
      const toolPhaseMap = getToolPhaseMap(mode);

      const copilotSession = await client.createSession({
        model: 'claude-sonnet-4.6',
        streaming: true,
        systemMessage: {
          mode: 'replace',
          content: systemPrompt,
        },
        tools,

        onPermissionRequest: approveAll,

        ...(mode === 'sdlc' ? {
          mcpServers: {
            github: {
              type: 'http',
              url: 'https://api.githubcopilot.com/mcp/',
              tools: ['*'],
            },
          },
        } : {}),

        hooks: {
          onPreToolUse: async (input: PreToolUseInput) => {
            console.log(`🔧 Tool call: ${input.toolName}`, JSON.stringify(input.toolArgs).slice(0, 200));
            return { permissionDecision: 'allow' as const };
          },
          onErrorOccurred: async (input: ErrorOccurredInput) => {
            console.error(`❌ Hook error [${input.errorContext}]:`, input.error);
            return { errorHandling: 'retry' as const };
          },
        },
      });

      // Stream tokens → WebSocket
      copilotSession.on('assistant.message_delta', (event) => {
        const chunk: string = (event as any)?.data?.deltaContent ?? '';
        if (chunk) sendToken(session.ws, chunk);
      });

      // Signal end-of-turn to frontend (use send() helper for readyState safety)
      copilotSession.on('session.idle', () => {
        send(session.ws, { type: 'agent_message_end' });
      });

      // Update workflow status badge on tool calls
      copilotSession.on('tool.execution_start', (event) => {
        const toolName: string = (event as any)?.data?.toolName ?? '';
        const phase = toolPhaseMap[toolName] ?? 'idle';
        sendStatus(session.ws, phase, `Running: ${toolName.replace(/_/g, ' ')}`);
      });

      // Log tool completions for debugging
      copilotSession.on('tool.execution_complete', (event) => {
        const toolName: string = (event as any)?.data?.toolName ?? (event as any)?.data?.toolCallId ?? '';
        console.log(`🔧 Tool complete: ${toolName}`);
      });

      session.copilotSession = copilotSession;
      console.log('✅ Copilot session ready');
    }

    await session.copilotSession.send({ prompt: userMessage });

  } catch (err) {
    // Log full error server-side; send sanitised message to client
    console.error('❌ processMessage error:', err);
    sendError(session.ws, 'An error occurred while processing your request. Please try again.');
  }
}

// ─── Register with handler (breaks circular dependency) ────────────────────
export function registerMessageProcessor(): void {
  setMessageProcessor(processMessage);
}

// ─── Graceful shutdown ─────────────────────────────────────────────────────
export async function stopCopilotClient(): Promise<void> {
  if (copilotClient && clientStarted) {
    console.log('🛑 Stopping Copilot CLI...');
    try {
      const errors = await copilotClient.stop();
      if (errors.length > 0) {
        console.error('Cleanup errors:', errors);
      }
    } catch {
      console.log('Forcing stop...');
      await copilotClient.forceStop();
    }
    copilotClient = null;
    clientStarted = false;
    console.log('✅ Copilot CLI stopped');
  }
}
