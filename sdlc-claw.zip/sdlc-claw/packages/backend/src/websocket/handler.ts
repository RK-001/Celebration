import { Server as HttpServer, IncomingMessage } from 'http';
import { WebSocket, WebSocketServer } from 'ws';
import { z } from 'zod';
import { config } from '../config';
import { AgentMode, AnyPhase, ServerEvent, WorkflowPhase } from '../types';

// Re-export types for internal use
export type { WorkflowPhase, AnyPhase, AgentMode };

// ──────────────────────────────────────────────
// Zod schemas for inbound messages (runtime validation)
// ──────────────────────────────────────────────

const UserMessageSchema = z.object({
  type: z.literal('user_message'),
  content: z.string().min(1).max(50_000),
});

const ConfirmResponseSchema = z.object({
  type: z.literal('confirm_response'),
  id: z.string().min(1).max(200),
  choice: z.enum(['approve', 'edit', 'reject']),
  edits: z.string().max(500_000).optional(),
});

const ClientEventSchema = z.discriminatedUnion('type', [
  UserMessageSchema,
  ConfirmResponseSchema,
]);

type ValidatedClientEvent = z.infer<typeof ClientEventSchema>;

// ──────────────────────────────────────────────
// WebSocket Session
// ──────────────────────────────────────────────

import type { CopilotSession } from '@github/copilot-sdk';

/** Per-connection session state */
export interface AgentSession {
  ws: WebSocket;
  mode: AgentMode;
  pendingConfirm: Map<string, {
    resolve: (choice: { choice: string; edits?: string }) => void;
  }>;
  currentPhase: AnyPhase;
  /** CopilotSession for multi-turn conversation (set by agent/session.ts) */
  copilotSession?: CopilotSession;
}

// ──────────────────────────────────────────────
// Send helpers
// ──────────────────────────────────────────────

export function send(ws: WebSocket, event: ServerEvent): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(event));
  }
}

export function sendToken(ws: WebSocket, token: string): void {
  send(ws, { type: 'agent_token', token });
}

export function sendStatus(ws: WebSocket, phase: AnyPhase, message: string): void {
  send(ws, { type: 'status_update', phase, message });
}

export function sendError(ws: WebSocket, message: string): void {
  send(ws, { type: 'error', message });
}

// ──────────────────────────────────────────────
// Confirmation gate — pauses agent, waits for user
// ──────────────────────────────────────────────

const CONFIRM_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes

export function waitForConfirmation(
  session: AgentSession,
  id: string,
  title: string,
  preview?: string,
  question?: string
): Promise<{ choice: string; edits?: string }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      session.pendingConfirm.delete(id);
      reject(new Error(`Confirmation "${id}" timed out after 10 minutes`));
    }, CONFIRM_TIMEOUT_MS);

    session.pendingConfirm.set(id, {
      resolve: (val) => {
        clearTimeout(timer);
        resolve(val);
      },
    });

    send(session.ws, {
      type: 'confirm_request',
      id,
      title,
      preview,
      question,
    });
  });
}

// ──────────────────────────────────────────────
// Per-connection rate limiter (sliding window)
// ──────────────────────────────────────────────

const RATE_LIMIT_WINDOW_MS = 10_000; // 10 seconds
const RATE_LIMIT_MAX = 30;           // max messages per window

function createRateLimiter() {
  const timestamps: number[] = [];
  return {
    /** Returns true if the message should be allowed. */
    allow(): boolean {
      const now = Date.now();
      // Remove expired timestamps
      while (timestamps.length > 0 && timestamps[0]! < now - RATE_LIMIT_WINDOW_MS) {
        timestamps.shift();
      }
      if (timestamps.length >= RATE_LIMIT_MAX) return false;
      timestamps.push(now);
      return true;
    },
  };
}

// ──────────────────────────────────────────────
// Cleanup pending confirmations on disconnect
// ──────────────────────────────────────────────

function cleanupSession(session: AgentSession, reason: string): void {
  for (const [id, pending] of session.pendingConfirm) {
    pending.resolve({ choice: 'reject', edits: `[Auto-rejected: ${reason}]` });
  }
  session.pendingConfirm.clear();
}

// ──────────────────────────────────────────────
// Message processing
// ──────────────────────────────────────────────

/** Pluggable message processor — set by agent/session.ts via setMessageProcessor() */
let messageProcessor: ((session: AgentSession, userMessage: string) => Promise<void>) | null = null;

/** Called once by agent/session.ts to wire up processMessage without circular imports. */
export function setMessageProcessor(
  fn: (session: AgentSession, userMessage: string) => Promise<void>
): void {
  messageProcessor = fn;
}

async function handleMessage(
  session: AgentSession,
  raw: string
): Promise<void> {
  // ── Zod validation ──
  let json: unknown;
  try {
    json = JSON.parse(raw);
  } catch {
    sendError(session.ws, 'Invalid JSON received');
    return;
  }

  const parsed = ClientEventSchema.safeParse(json);
  if (!parsed.success) {
    sendError(session.ws, 'Invalid message format');
    console.warn('WS validation error:', parsed.error.issues);
    return;
  }
  const event: ValidatedClientEvent = parsed.data;

  if (event.type === 'user_message') {
    if (!messageProcessor) {
      sendError(session.ws, 'Agent not initialised yet');
      return;
    }
    await messageProcessor(session, event.content);
    return;
  }

  if (event.type === 'confirm_response') {
    const pending = session.pendingConfirm.get(event.id);
    if (pending) {
      session.pendingConfirm.delete(event.id);
      pending.resolve({ choice: event.choice, edits: event.edits });
    }
    return;
  }
}

// ──────────────────────────────────────────────
// WebSocket server setup
// ──────────────────────────────────────────────

const HEARTBEAT_INTERVAL_MS = 30_000; // 30 seconds

export function setupWebSocket(server: HttpServer): WebSocketServer {
  const wss = new WebSocketServer({
    server,
    maxPayload: 1 * 1024 * 1024, // 1 MB — prevents memory exhaustion
  });

  // ── Heartbeat: detect dead connections ──
  const aliveMap = new WeakMap<WebSocket, boolean>();

  const heartbeatTimer = setInterval(() => {
    for (const client of wss.clients) {
      if (aliveMap.get(client) === false) {
        console.log('💀 Terminating dead WebSocket (no pong)');
        client.terminate();
        continue;
      }
      aliveMap.set(client, false);
      client.ping();
    }
  }, HEARTBEAT_INTERVAL_MS);

  wss.on('close', () => clearInterval(heartbeatTimer));

  wss.on('connection', (ws: WebSocket, request: IncomingMessage) => {
    const url = new URL(request.url ?? '/', `http://${request.headers.host ?? 'localhost'}`);

    // ── Auth: validate shared secret (if configured) ──
    if (config.wsAuthToken) {
      const token = url.searchParams.get('token');
      if (token !== config.wsAuthToken) {
        console.warn('🚫 WebSocket connection rejected — invalid token');
        ws.close(4401, 'Unauthorized');
        return;
      }
    }

    // ── Origin check ──
    const origin = request.headers.origin;
    if (origin && origin !== config.corsOrigin) {
      console.warn(`🚫 WebSocket connection rejected — origin mismatch: ${origin}`);
      ws.close(4403, 'Forbidden origin');
      return;
    }

    // ── Parse mode ──
    const modeParam = url.searchParams.get('mode');
    const mode: AgentMode = modeParam === 'us-creator' ? 'us-creator' : 'sdlc';

    console.log(`🔌 New WebSocket connection [mode=${mode}]`);

    const session: AgentSession = {
      ws,
      mode,
      pendingConfirm: new Map(),
      currentPhase: 'idle',
    };

    // ── Heartbeat tracking ──
    aliveMap.set(ws, true);
    ws.on('pong', () => aliveMap.set(ws, true));

    // ── Rate limiter ──
    const limiter = createRateLimiter();

    // Notify frontend the agent is ready (include mode)
    send(ws, { type: 'agent_ready', mode });

    ws.on('message', (data) => {
      if (!limiter.allow()) {
        sendError(ws, 'Rate limit exceeded — slow down');
        ws.close(4429, 'Too many requests');
        return;
      }
      handleMessage(session, data.toString()).catch((err) => {
        console.error('Error handling message:', err);
        // Sanitised error — never leak internals to client
        sendError(ws, 'An internal error occurred');
      });
    });

    ws.on('close', () => {
      console.log(`🔌 WebSocket connection closed [mode=${mode}]`);
      cleanupSession(session, 'client disconnected');
    });

    ws.on('error', (err) => {
      console.error('WebSocket error:', err);
      cleanupSession(session, 'WebSocket error');
    });
  });

  return wss;
}
