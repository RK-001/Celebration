# BRD Template

> Reference template for the US Creator agent. The AI fills these sections via system prompt instructions.

---

# BRD: {Feature Title}

| Property | Value |
|----------|-------|
| **Document Version** | 1.0 |
| **Date** | {YYYY-MM-DD} |
| **Author** | US Creator Copilot |
| **Status** | Draft — Pending Review |
| **Related User Story** | {US-XXXX} |
| **Priority** | {Critical / High / Medium / Low} |

---

## 1. Executive Summary
{2-3 paragraphs: what this feature does, why it is needed, high-level approach}

## 2. Business Requirements

### 2.1 User Story
{As a / I want / So that}

### 2.2 Business Context
{Problem statement, current process gaps, expected benefits}

### 2.3 Scope

#### In Scope
- {bullet list}

#### Out of Scope
- {bullet list}

## 3. Functional Requirements

| ID | Requirement | Priority | Testable |
|----|------------|----------|----------|
| FR-1 | {Clear, testable statement} | {Must/Should/Could} | Yes |
| FR-2 | {Clear, testable statement} | {Must/Should/Could} | Yes |

## 4. Non-Functional Requirements

| ID | Requirement | Target |
|----|------------|--------|
| NFR-1 | {Performance / Security / Scalability} | {Measurable target} |
| NFR-2 | {Performance / Security / Scalability} | {Measurable target} |

## 5. High-Level Process Flow

### 5.1 Process Description
{Step-by-step description of the flow}

### 5.2 Flow Diagram

```mermaid
flowchart TD
    A[Start] --> B[Step 1]
    B --> C{Decision}
    C -->|Yes| D[Step 2a]
    C -->|No| E[Step 2b]
    D --> F[End]
    E --> F
```

## 6. Data Model Considerations

### 6.1 New Objects/Entities
| Entity | Purpose | Key Fields |
|--------|---------|-----------|
| {Entity name} | {Why it exists} | {Key fields} |

### 6.2 Modified Objects/Entities
| Entity | Field | Current | New | Reason |
|--------|-------|---------|-----|--------|
| {Entity} | {Field} | {Current behavior} | {New behavior} | {Why} |

## 7. Controls & Validations

| Validation | Condition | Error Message | Severity |
|-----------|-----------|---------------|----------|
| {Name} | {When it triggers} | {Message} | Error/Warning |

## 8. Error Handling

| Error Scenario | Detection | Response | Recovery |
|---------------|-----------|----------|----------|
| {Scenario} | {How detected} | {Action} | {How to recover} |

## 9. Acceptance Criteria

| # | Given | When | Then |
|---|-------|------|------|
| AC-1 | {Pre-condition} | {Action} | {Expected result} |

## 10. Dependencies & Risks

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| {Risk} | H/M/L | H/M/L | {Strategy} |

## 11. Appendices

### A. Glossary
| Term | Definition |
|------|-----------|
| {Term} | {Definition} |

### B. Open Questions
- {Unresolved item 1}
- {Unresolved item 2}

### C. Change Log
| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | {date} | US Creator Copilot | Initial draft |
