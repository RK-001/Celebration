# User Story Template

> Reference template for the US Creator agent. The AI fills these sections via system prompt instructions.

---

## US-{NUMBER}: {Title}

**As a** {persona},
**I want** {action — what the system should do},
**So that** {business value — why this matters}.

### Business Context
{2-3 sentences explaining the business problem and solution}

### Scope

#### In Scope
- {Specific capability 1}
- {Specific capability 2}

#### Out of Scope
- {Excluded item 1}
- {Excluded item 2}

### Acceptance Criteria

| # | Given | When | Then |
|---|-------|------|------|
| AC-1 | {Pre-condition} | {Action/trigger} | {Expected result} |
| AC-2 | {Pre-condition} | {Action/trigger} | {Expected result} |
| AC-3 | {Pre-condition} | {Action/trigger} | {Expected result} |

### Technical Notes
- **Affected Systems/Components:** {list}
- **Integration Points:** {APIs, services, events}
- **Data Changes:** {new/modified fields, objects}

### Metadata

| Property | Value |
|----------|-------|
| **Priority** | {Critical / High / Medium / Low} |
| **Estimated Complexity** | {S / M / L / XL} |
| **Related Stories** | {US/CR numbers or "None"} |
| **Dependencies** | {External dependencies or "None"} |
