import express from 'express';
import http from 'http';
import cors from 'cors';
import { config } from './config';
import { setupWebSocket } from './websocket/handler';
import { stopCopilotClient, registerMessageProcessor } from './agent/session';

const app = express();
app.use(express.json());
app.use(cors({ origin: config.corsOrigin }));

// Health check
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Create HTTP server (shared with WebSocket)
const server = http.createServer(app);

// Wire up agent → handler (breaks circular dependency)
registerMessageProcessor();

// Attach WebSocket
setupWebSocket(server);

server.listen(config.port, () => {
  console.log(`\n🚀 SDLC Agent backend running at http://localhost:${config.port}`);
  console.log(`🔌 WebSocket ready at ws://localhost:${config.port}`);
  console.log(`🏥 Health check: http://localhost:${config.port}/health\n`);
});

// ─── Graceful shutdown ─────────────────────────────────────────────────────
async function shutdown() {
  console.log('\n🛑 Shutting down...');
  await stopCopilotClient();
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
  // Force exit after 5s if graceful shutdown hangs — .unref() so it
  // doesn't keep the event loop alive after a clean close.
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

// Catch unhandled rejections to avoid silent crashes
process.on('unhandledRejection', (reason) => {
  console.error('⚠️ Unhandled rejection:', reason);
});

export { app, server };
