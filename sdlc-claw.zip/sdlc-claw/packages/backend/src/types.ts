// ──────────────────────────────────────────────
// Re-export all shared types from the single source of truth.
// Keeps existing import paths working without changes.
// ──────────────────────────────────────────────
export type {
  UserMessageEvent,
  ConfirmResponseEvent,
  ClientEvent,
  AgentTokenEvent,
  AgentMessageEndEvent,
  ConfirmRequestEvent,
  StatusUpdateEvent,
  ErrorEvent,
  AgentReadyEvent,
  ServerEvent,
  AgentMode,
  WorkflowPhase,
  USCreatorPhase,
  AnyPhase,
  WorkItemSummary,
} from '@sdlc-agent/shared';
