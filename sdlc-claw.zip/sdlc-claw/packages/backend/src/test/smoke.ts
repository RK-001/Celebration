/**
 * Smoke test — Step 2 verification
 * Usage: npx ts-node src/test/smoke.ts <workItemId>
 *
 * This script verifies:
 * 1. Config loads correctly (all env vars present)
 * 2. Azure DevOps connection works
 * 3. Work item fetches and parses correctly
 */
import { getWorkItem } from '../services/azureDevOps';

async function main() {
  const id = parseInt(process.argv[2] ?? '', 10);
  if (isNaN(id)) {
    console.error('Usage: npx ts-node src/test/smoke.ts <workItemId>');
    console.error('Example: npx ts-node src/test/smoke.ts 123');
    process.exit(1);
  }

  console.log(`\n🔍 SDLC Agent — Smoke Test`);
  console.log('─'.repeat(50));

  // Step 1: Config
  try {
    const { config } = await import('../config');
    console.log(`✅ Config loaded`);
    console.log(`   ADO Org:     ${config.ado.org}`);
    console.log(`   ADO Project: ${config.ado.project}`);
    console.log(`   GitHub Org:  ${config.github.org}`);
  } catch (err) {
    console.error(`❌ Config failed:`, err instanceof Error ? err.message : err);
    process.exit(1);
  }

  // Step 2: Fetch work item
  console.log(`\n📋 Fetching Work Item #${id}...`);
  try {
    const item = await getWorkItem(id);

    console.log(`✅ Work item fetched successfully!`);
    console.log('─'.repeat(50));
    console.log(`   ID:          ${item.id}`);
    console.log(`   Type:        ${item.type}`);
    console.log(`   Title:       ${item.title}`);
    console.log(`   State:       ${item.state}`);
    console.log(`   Assigned To: ${item.assignedTo}`);
    console.log(`   Priority:    ${item.priority}`);
    console.log(`   Tags:        ${item.tags || '(none)'}`);
    console.log(`   URL:         ${item.url}`);
    console.log('');
    console.log(`   Description (first 200 chars):`);
    console.log(`   ${item.description.substring(0, 200)}...`);

    if (item.acceptanceCriteria) {
      console.log('');
      console.log(`   Acceptance Criteria (first 200 chars):`);
      console.log(`   ${item.acceptanceCriteria.substring(0, 200)}...`);
    }

    if (item.comments.length > 0) {
      console.log('');
      console.log(`   Comments: ${item.comments.length} found`);
    }

    console.log('\n✅ ALL CHECKS PASSED — Azure DevOps service is working correctly.\n');
  } catch (err) {
    console.error(`\n❌ Failed to fetch work item #${id}:`);
    if (err instanceof Error) {
      console.error(`   ${err.message}`);
      if ((err as any).response?.status === 401) {
        console.error('   → Check your ADO_PAT token. It may be expired or have insufficient permissions.');
      } else if ((err as any).response?.status === 404) {
        console.error(`   → Work item #${id} was not found. Check the ID and ADO_PROJECT setting.`);
      }
    }
    process.exit(1);
  }
}

main();
