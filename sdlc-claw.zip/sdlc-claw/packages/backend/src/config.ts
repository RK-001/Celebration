import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// ESM equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env from the root of the monorepo
dotenv.config({ path: path.resolve(__dirname, '../../..', '.env') });

function requireEnv(name: string): string {
  const val = process.env[name];
  if (!val) throw new Error(`Missing required env variable: ${name}`);
  return val;
}

function parsePort(raw: string | undefined, fallback: number): number {
  const n = parseInt(raw ?? String(fallback), 10);
  if (Number.isNaN(n) || n < 1 || n > 65535) {
    throw new Error(`Invalid PORT value: "${raw}". Must be 1-65535.`);
  }
  return n;
}

export const config = {
  port: parsePort(process.env['PORT'], 4000),

  /** Allowed origin for CORS and WebSocket origin checks */
  corsOrigin: process.env['CORS_ORIGIN'] ?? 'http://localhost:3000',

  /** Shared secret for WebSocket authentication (optional — if unset, auth is disabled) */
  wsAuthToken: process.env['WS_AUTH_TOKEN'] ?? '',

  ado: {
    org: requireEnv('ADO_ORG'),
    project: requireEnv('ADO_PROJECT'),
    pat: requireEnv('ADO_PAT'),
  },

  github: {
    token: requireEnv('GITHUB_TOKEN'),
    org: process.env['GITHUB_ORG'] ?? '',
    repos: (process.env['GITHUB_REPOS'] ?? '').split(',').filter(Boolean),
  },
};
