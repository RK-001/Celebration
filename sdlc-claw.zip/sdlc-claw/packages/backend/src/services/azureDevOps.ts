import axios, { AxiosInstance } from 'axios';
import { config } from '../config';

// ──────────────────────────────────────────────
// Types
// ──────────────────────────────────────────────

export interface WorkItem {
  id: number;
  type: string;         // "User Story" | "Bug" | "Task"
  title: string;
  description: string;
  acceptanceCriteria: string;
  state: string;        // "New" | "Active" | "Resolved" | "Closed"
  priority: number;
  assignedTo: string;
  areaPath: string;
  tags: string;
  url: string;
  comments: WorkItemComment[];
}

export interface WorkItemComment {
  id: number;
  text: string;
  author: string;
  createdDate: string;
}

/** Shape of a single comment from the ADO REST API */
interface AdoCommentResponse {
  id: number;
  text?: string;
  createdBy?: { displayName?: string };
  createdDate?: string;
}

// ──────────────────────────────────────────────
// HTTP Client — singleton (one TCP pool, PAT encoded once)
// ──────────────────────────────────────────────

let _adoClient: AxiosInstance | null = null;

function getAdoClient(): AxiosInstance {
  if (!_adoClient) {
    const token = Buffer.from(`:${config.ado.pat}`).toString('base64');
    const baseURL = `https://dev.azure.com/${config.ado.org}/${config.ado.project}`;
    _adoClient = axios.create({
      baseURL,
      headers: {
        Authorization: `Basic ${token}`,
        'Content-Type': 'application/json',
      },
      timeout: 30_000, // 30s request timeout
    });
  }
  return _adoClient;
}

// ──────────────────────────────────────────────
// Functions
// ──────────────────────────────────────────────

/**
 * Fetch a work item by ID — returns all fields + comments.
 */
export async function getWorkItem(id: number): Promise<WorkItem> {
  const client = getAdoClient();

  const { data } = await client.get(
    `/_apis/wit/workitems/${id}?$expand=all&api-version=7.1`
  );

  const f = data.fields;

  // Fetch comments separately
  const comments = await getWorkItemComments(id);

  return {
    id: data.id,
    type: f['System.WorkItemType'] ?? '',
    title: f['System.Title'] ?? '',
    description: stripHtml(f['System.Description'] ?? ''),
    acceptanceCriteria: stripHtml(f['Microsoft.VSTS.Common.AcceptanceCriteria'] ?? ''),
    state: f['System.State'] ?? '',
    priority: f['Microsoft.VSTS.Common.Priority'] ?? 0,
    assignedTo: f['System.AssignedTo']?.displayName ?? 'Unassigned',
    areaPath: f['System.AreaPath'] ?? '',
    tags: f['System.Tags'] ?? '',
    url: `https://dev.azure.com/${config.ado.org}/${config.ado.project}/_workitems/edit/${id}`,
    comments,
  };
}

/**
 * Fetch discussion comments for a work item.
 */
export async function getWorkItemComments(id: number): Promise<WorkItemComment[]> {
  const client = getAdoClient();
  try {
    const { data } = await client.get(
      `/_apis/wit/workitems/${id}/comments?api-version=7.1-preview.3`
    );
    return (data.comments ?? []).map((c: AdoCommentResponse) => ({
      id: c.id,
      text: stripHtml(c.text ?? ''),
      author: c.createdBy?.displayName ?? 'Unknown',
      createdDate: c.createdDate ?? '',
    }));
  } catch (err) {
    // Comments API might not be available in all tiers — log but don't crash
    console.warn(`⚠️ Failed to fetch comments for work item ${id}:`, err instanceof Error ? err.message : err);
    return [];
  }
}

/**
 * Upload a file as an attachment to Azure DevOps.
 * Returns the attachment URL to be linked to a work item.
 */
export async function uploadAttachment(
  fileName: string,
  content: Buffer
): Promise<string> {
  const client = getAdoClient();
  const { data } = await client.post(
    `/_apis/wit/attachments?fileName=${encodeURIComponent(fileName)}&api-version=7.1`,
    content,
    {
      headers: {
        'Content-Type': 'application/octet-stream',
      },
    }
  );
  return data.url as string;
}

/**
 * Link an already-uploaded attachment to a work item.
 */
export async function linkAttachment(
  workItemId: number,
  attachmentUrl: string,
  comment: string = ''
): Promise<void> {
  const client = getAdoClient();
  const patch = [
    {
      op: 'add',
      path: '/relations/-',
      value: {
        rel: 'AttachedFile',
        url: attachmentUrl,
        attributes: { comment },
      },
    },
  ];
  await client.patch(
    `/_apis/wit/workitems/${workItemId}?api-version=7.1`,
    patch,
    {
      headers: { 'Content-Type': 'application/json-patch+json' },
    }
  );
}

// ──────────────────────────────────────────────
// Utilities
// ──────────────────────────────────────────────

/** Strip HTML tags from ADO rich-text fields */
function stripHtml(html: string): string {
  return html
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_m, code) => String.fromCharCode(Number(code)))
    .trim();
}
